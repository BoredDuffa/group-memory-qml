"""Render the frozen improved-sensor evidence without rerunning experiments.

The notebook embeds a compact saved-data snapshot and editable plotting code.
Only --execute runs its display cells; it never imports the project, trains,
downloads data or evaluates a quantum circuit. Audit/CSV statistics come from
the separate evidence audit, not from this presentation builder.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import statistics
import time

import nbformat

WORK = Path(__file__).resolve().parent
REPO = WORK.parent/'group-memory-qml'
METHODS = ['group_spectral','qiskit_response','classical_adjoint','frozen_quantum',
           'classical_logistic','classical_rbf','classical_mlp']
LABELS = dict(zip(METHODS, ['GroupMemory','Qiskit · same response','Same-model adjoint',
                          'Frozen quantum angles','Logistic regression','RBF SVM','Classical MLP']))


def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read_csv(path):
    return list(csv.DictReader(path.open(newline=''))) if path.exists() else []


def snapshot(campaigns, evidence, main_condition=None):
    attempt_rows=[];manifest={};configurations=[];coverage=[]
    for campaign in campaigns:
        cfg=read(campaign/'config.json');configurations.append(cfg)
        for index,spec in enumerate(cfg['plan']):
            path=campaign/'attempts'/f'{index:05d}.json'
            row=read(path) if path.exists() else dict(spec=spec,status='UNATTEMPTED')
            if row['spec']!=spec:raise ValueError(f'Plan mismatch in {campaign.name}/{path.name}')
            if path.exists():manifest[f'{campaign.name}/attempts/{path.name}']=sha(path)
            cost_path=campaign/'attempt_costs'/path.name
            if cost_path.exists():
                cost=read(cost_path)
                row['_report_parent_loop_s']=cost['parent_loop_wall_s']
                manifest[f'{campaign.name}/attempt_costs/{path.name}']=sha(cost_path)
            elif row.get('status')=='SUCCESS':
                raise ValueError('Stable report requires every parent-loop timing sidecar')
            attempt_rows.append((campaign.name,cfg['repeats'],row))
        for condition in cfg['conditions']:
            counts=Counter(row['status'] for name,_,row in attempt_rows
                           if name==campaign.name and row['spec']['condition']==condition['id'])
            coverage.append(dict(campaign=campaign.name,condition=condition['id'],**counts))
    identities=set()
    for campaign,_,row in attempt_rows:
        spec=row['spec'];key=(spec['condition'],spec['seed'],spec['repeat'],spec['method'])
        if key in identities:raise ValueError('Overlapping campaign identities; refusing to pool')
        identities.add(key)
    audit=read(evidence/'audit.json') if (evidence/'audit.json').exists() else None
    if audit is not None:
        if (audit.get('status')!='PASS' or audit.get('errors')!=[]
                or audit.get('complete_successful_coverage') is not True
                or not isinstance(audit.get('max_matching_error'),(int,float))
                or not 0 <= audit['max_matching_error'] <= 1e-10):
            raise ValueError('Complete independent correctness audit has not passed the unchanged 1e-10 threshold')
        if (audit['planned_attempts']!=len(attempt_rows) or audit['successful_attempts']!=
                sum(row['status']=='SUCCESS' for _,_,row in attempt_rows)):
            raise ValueError('Audit coverage differs from the supplied campaigns')
    successful=[(campaign,repeats,row) for campaign,repeats,row in attempt_rows if row['status']=='SUCCESS']
    groups=defaultdict(list)
    for campaign,repeats,row in successful:
        spec=row['spec'];groups[spec['condition'],spec['seed'],spec['method'],repeats].append(row)
    seeds=[];learning=[];classical=[];conditions={}
    for cfg in configurations:
        conditions.update({c['id']:c['config'] for c in cfg['conditions']})
    if main_condition is None:
        main=[name for name,cfg in conditions.items()
              if cfg.get('representation')=='lda_tiled' and cfg.get('steps')==1000]
        if len(main)!=1:raise ValueError('Specify --main-condition for an ambiguous main recipe')
        main_condition=main[0]
    for (condition,seed,method,repeats),group in sorted(groups.items()):
        if {row['spec']['repeat'] for row in group}!=set(range(repeats)):continue
        group.sort(key=lambda row:row['spec']['repeat']);row=group[0]
        d=row['diagnostics'];metrics=row['test_metrics']
        if metrics is None:raise ValueError('Report expects final evaluated records, not development search')
        seeds.append(dict(condition=condition,seed=seed,method=method,repeats=repeats,
            process_s=statistics.median(r['process_wall_s'] for r in group),
            runtime_s=statistics.median(r['_report_parent_loop_s'] for r in group),
            application_s=statistics.median(r['application_s'] for r in group),
            accuracy=metrics['accuracy'],balanced_accuracy=metrics['balanced_accuracy'],
            log_loss=metrics['log_loss'],selected_step=d.get('selected_checkpoint_step'),
            selected_view=d.get('selected_feature_view'),
            moved_angles=d.get('parameter_training',{}).get('moved_parameters') if d.get('parameter_training') else None))
        if method in ('group_spectral','frozen_quantum'):
            learning.append(dict(condition=condition,seed=seed,method=method,
                initial_validation=d['initial_validation_metrics'],
                trajectory=d['training_trajectory'],selected_step=d['selected_checkpoint_step']))
        if method in ('classical_logistic','classical_rbf','classical_mlp'):
            classical.append(dict(condition=condition,seed=seed,method=method,
                selected_view=d['selected_feature_view'],candidates=d['classical_candidates']))
    first=successful[0][2] if successful else None
    provenance={} if first is None else first['diagnostics']['provenance']
    # No row-level raw observations or private filesystem paths are embedded.
    provenance={key:value for key,value in provenance.items() if key in (
        'dataset','dataset_url','citation','doi','license','license_discrepancy',
        'bundled_readme_license','archive_sha256','prepared_npz_sha256',
        'class_names','test_policy','independence','heldout_contract_sha256')}
    timings=read(evidence/'timing_accounting.json') if (evidence/'timing_accounting.json').exists() else None
    study_ledger=read(evidence/'study_cost_ledger.json') if (evidence/'study_cost_ledger.json').exists() else None
    stability=[]
    for name in ('stable_sensor_pilot.json','stable_sensor_confirmation.json','stable_sensor_lower_lr.json'):
        path=evidence/name
        if path.exists():
            receipt=read(path)
            stability.append(dict(receipt=name,status=receipt.get('status'),
                external_process_wall_s=receipt.get('external_process_wall_s'),
                selected_candidate=receipt.get('selected_candidate'),
                records=[{key:row.get(key) for key in ('seed','epsilon','learning_rate','methods','status',
                    'completed_steps','max_error','selected_steps_match','selected_params_maxerror',
                    'selected_validation_probability_maxerror','common_point_max_errors','seconds')}
                    for row in receipt.get('records',[])]))
    repair=read(evidence/'numerical_repair.json') if (evidence/'numerical_repair.json').exists() else {}
    tables={name:read_csv(evidence/(name+'.csv')) for name in ('summary','comparisons','seed_medians','summary_all_overhead','comparisons_all_overhead','seed_medians_all_overhead')}
    hashes={path.name:sha(path) for path in [evidence/'audit.json',evidence/'timing_accounting.json',
            evidence/'summary.csv',evidence/'comparisons.csv',evidence/'seed_medians.csv',
            evidence/'summary_all_overhead.csv',evidence/'comparisons_all_overhead.csv',
            evidence/'seed_medians_all_overhead.csv',evidence/'numerical_repair.json',
            evidence/'selection_freeze.json',evidence/'pilot_audit.json',
            evidence/'study_cost_ledger.json'] if path.exists()}
    failures=[dict(campaign=campaign,**row['spec'],status=row['status'],
                   error=row.get('error',row.get('stderr',''))[:1000])
              for campaign,_,row in attempt_rows if row['status']!='SUCCESS']
    return dict(snapshot_utc=datetime.now(timezone.utc).isoformat(),main_condition=main_condition,
        conditions=conditions,methods=METHODS,labels=LABELS,coverage=coverage,
        planned=len(attempt_rows),successful=len(successful),failures=failures,
        seeds=seeds,learning=learning,classical=classical,audit=audit,tables=tables,
        timing=timings,study_cost_ledger=study_ledger,numerical_repair=repair,stability=stability,provenance=provenance,attempt_sha256=manifest,evidence_sha256=hashes,
        source_hashes=configurations[0]['source_hashes'],
        environment=read(campaigns[0]/'environment.json'),
        source_links={'repository':'https://github.com/BoredDuffa/group-memory-qml',
        'dataset':'https://archive.ics.uci.edu/dataset/240/human+activity+recognition+using+smartphones',
        'dataset_doi':'https://doi.org/10.24432/C54S4K'},
        scope='Presentation from saved final records; no benchmark/model execution')


SETUP=r'''
import hashlib,json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display,HTML,Markdown
assert hashlib.sha256(SNAPSHOT_JSON.encode()).hexdigest()==SNAPSHOT_SHA256
data=json.loads(SNAPSHOT_JSON)
labels=data['labels'];methods=data['methods'];main=data['main_condition']
frame=pd.DataFrame(data['seeds']);mainframe=frame[frame.condition==main].copy()
colors={'group_spectral':'#176C60','qiskit_response':'#326CA7',
        'classical_adjoint':'#B66A2D','frozen_quantum':'#819A68',
        'classical_logistic':'#6B7280','classical_rbf':'#4B5563','classical_mlp':'#9CA3AF'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                    'axes.spines.right':False,'axes.titleweight':'bold','axes.axisbelow':True,
                    'figure.facecolor':'white','savefig.facecolor':'white'})
display(HTML('<style>.jp-Notebook{max-width:1150px;margin:auto} '
 '.jp-RenderedHTMLCommon h1,.jp-RenderedHTMLCommon h2{color:#17473E}'
 '.jp-RenderedHTMLCommon p,.jp-RenderedHTMLCommon li{line-height:1.55}'
 '.jp-RenderedHTMLCommon th{background:#EEF4F1;padding:9px}'
 '.jp-RenderedHTMLCommon td{padding:8px}.evidence{background:#EEF4F1;padding:18px;border-left:4px solid #176C60}</style>'))
def table(rows,formats=None):
    f=pd.DataFrame(rows)
    if f.empty:display(Markdown('No complete records available.'));return
    display(HTML(f.to_html(index=False,escape=True,formatters=formats)))
def boolean(value):return value is True or str(value).lower()=='true'
def mainrows(method):return mainframe[mainframe.method==method]
def save(name):plt.savefig(name+'.png',dpi=160,bbox_inches='tight');plt.show()
'''

HEADLINE=r'''
audit=data['audit']
coverage=(f"{data['successful']}/{data['planned']} planned attempts succeeded")
display(HTML('<div class="evidence"><b>'+coverage+'</b><br>'
             'Real smartphone activity classification · ideal CPU simulation · frozen final recipe</div>'))
gm=mainrows('group_spectral');qiskit=mainrows('qiskit_response');frozen=mainrows('frozen_quantum')
if len(gm):
    display(Markdown(f"The selected LDA-based model reaches **{100*gm.balanced_accuracy.mean():.2f}%** "
      f"mean balanced test accuracy in **{gm.runtime_s.median():.3f}s** median complete attempt time (including the worker). "
      "These are descriptive averages across training seeds on one fixed held-out row set."))
if len(qiskit):
    display(Markdown(f"Equally informed Qiskit reaches **{100*qiskit.balanced_accuracy.mean():.2f}%** "
      f"in **{qiskit.runtime_s.median():.3f}s**. GroupMemory and Qiskit evaluate the same function "
      "and follow the same training trajectory; memory changes runtime, not predictive accuracy."))
if len(frozen):
    display(Markdown(f"Keeping the quantum angles fixed reaches **{100*frozen.balanced_accuracy.mean():.2f}%** "
      f"in **{frozen.runtime_s.median():.3f}s**. This control tests how much of the improvement "
      "already comes from supervised LDA and the classical softmax head."))
if audit:
    display(Markdown(f"Independent audit: **{audit['status']}**; matching-vector maximum error "
      f"**{audit['max_matching_error']:.3g}**, required **≤1e−10**. "
      f"Matched QML blocks: **{audit['matched_qml_blocks']}**."))
else:display(Markdown('**Draft: independent audit unavailable; no validated win claims.**'))
display(Markdown('Primary runtime assumes the prepared dataset is already available. The next cost table '
 'also charges every method the same recorded initial acquisition components; study search and repair costs are reported separately.'))
'''

MAINFIGURE=r'''
present=[method for method in methods if len(mainrows(method))]
y=np.arange(len(present))
times=[mainrows(method).runtime_s.median() for method in present]
scores=[100*mainrows(method).balanced_accuracy.mean() for method in present]
fig,axes=plt.subplots(1,2,figsize=(12.8,4.9),sharey=True)
axes[0].barh(y,times,color=[colors[m] for m in present],height=.65)
axes[1].barh(y,scores,color=[colors[m] for m in present],height=.65)
axes[0].set_yticks(y,[labels[m] for m in present]);axes[0].invert_yaxis()
axes[0].set(xlabel='Complete attempt seconds · median of seed medians',xlim=(0,None),title='Runtime with prepared data')
axes[1].set(xlabel='Balanced test accuracy (%) · mean across seeds',xlim=(0,100),title='Held-out classification')
axes[1].axvline(100/6,color='#444444',linestyle='--',linewidth=1)
axes[1].text(100/6+1,.98,'Chance 16.7%',fontsize=9,va='top',transform=axes[1].get_xaxis_transform())
for ax,values in zip(axes,(times,scores)):
    ax.grid(axis='x',alpha=.16)
    for row,value in enumerate(values):
        if ax is axes[1] and value>92:
            ax.text(value-1.5,row,f'{value:.2f}',ha='right',va='center',fontsize=9,color='white')
        else:
            ax.text(value+.02*max(values),row,f'{value:.2f}',va='center',fontsize=9)
axes[0].set_xlim(0,max(times)*1.15 if times else 1)
fig.tight_layout();save('main_runtime_accuracy')
display(Markdown('Both magnitude axes start at zero. Runtime includes the complete fresh interpreter '
 'lifecycle; the initial dataset acquisition and whole-study costs are reported separately. '
 'Two timing repeats are collapsed within each seed before aggregation. Repeats do not supply new test data.'))
table([{'Method':labels[m],'Seeds':len(mainrows(m)),
        'Complete attempt s':float(mainrows(m).runtime_s.median()),
        'Worker process s':float(mainrows(m).process_s.median()),
        'Accuracy %':100*float(mainrows(m).accuracy.mean()),
        'Balanced %':100*float(mainrows(m).balanced_accuracy.mean()),
        'Balanced range %':f'{100*mainrows(m).balanced_accuracy.min():.2f}–{100*mainrows(m).balanced_accuracy.max():.2f}',
        'Test log loss':float(mainrows(m).log_loss.mean())} for m in present],
      {'Complete attempt s':'{:.3f}'.format,'Worker process s':'{:.3f}'.format,'Accuracy %':'{:.2f}'.format,
       'Balanced %':'{:.2f}'.format,'Test log loss':'{:.4f}'.format})
acquisition=None if data['timing'] is None else data['timing'].get('common_acquisition_components_s')
if acquisition is not None:
    acquisition=float(acquisition)
    display(Markdown(f"**One-off dataset setup sensitivity:** add the same **{acquisition:.6f}s** recorded "
      "download/extraction/parsing/write component sum to each method as a standalone-use scenario."))
    table([{'Method':labels[m],'Complete attempt s · prepared data':float(mainrows(m).runtime_s.median()),
            'Plus acquisition components s':float(mainrows(m).runtime_s.median())+acquisition}
           for m in present],{'Complete attempt s · prepared data':'{:.3f}'.format,
                              'Plus acquisition components s':'{:.3f}'.format})
    g=mainrows('group_spectral').set_index('seed');q=mainrows('qiskit_response').set_index('seed')
    paired=sorted(set(g.index)&set(q.index))
    if paired:
        base=[100*(1-g.loc[seed,'runtime_s']/q.loc[seed,'runtime_s']) for seed in paired]
        adjusted=[100*(1-(g.loc[seed,'runtime_s']+acquisition)/(q.loc[seed,'runtime_s']+acquisition)) for seed in paired]
        table([{'Paired Qiskit comparison':'Prepared dataset','Seeds':len(paired),'Median paired saving %':float(np.median(base))},
               {'Paired Qiskit comparison':'Plus same acquisition components','Seeds':len(paired),'Median paired saving %':float(np.median(adjusted))}],
              {'Median paired saving %':'{:+.2f}'.format})
    display(Markdown('This is a **derived component sum**, not a measured complete first-use wall clock. '
      'Package installation, unmeasured search imports and other unrecorded setup remain outside it. '
      'The same additive setup cost preserves every faster/slower ordering but reduces percentage differences; '
      'a 5% descriptive saving threshold can therefore change. The shared setup is added once per standalone '
      'scenario, not repeatedly summed across methods or added again to the study ledger.'))
'''

ABLATIONS=r'''
recipe_order=[('pca_original',60),('pca_original',1000),('pca_shifted',1000),('lda_tiled',1000)]
recipe_labels=['Original PCA\n60 updates','Original PCA\n1,000 updates',
               'Shifted/compressed PCA\n1,000 updates','Supervised LDA\n1,000 updates']
recipe_rows=[];series=[]
for (representation,steps),label in zip(recipe_order,recipe_labels):
    candidates=[name for name,cfg in data['conditions'].items()
                if cfg.get('representation')==representation and cfg.get('steps')==steps]
    if len(candidates)>1:raise ValueError('Ambiguous quality ablation')
    subset=frame[(frame.condition.isin(candidates))&(frame.method=='group_spectral')]
    values=subset.balanced_accuracy.to_numpy(float)*100
    series.append(values)
    if len(values):recipe_rows.append({'Recipe':label.replace('\n',' · '),'Seeds':len(values),
      'Balanced accuracy %':float(values.mean()),'Mean test log loss':float(subset.log_loss.mean()),
      'Median complete attempt s':float(subset.runtime_s.median())})
fig,ax=plt.subplots(figsize=(11.5,4.5))
means=[np.mean(values) if len(values) else np.nan for values in series]
ax.bar(range(4),means,color=['#969DA7','#7E8998','#326CA7','#176C60'],width=.64)
for index,values in enumerate(series):
    if len(values):
        offsets=np.linspace(-.12,.12,len(values))
        ax.scatter(index+offsets,values,s=23,c='white',edgecolor='#343434',linewidth=.8,zorder=3)
        ax.text(index,means[index]+3,f'{means[index]:.1f}%',ha='center')
ax.axhline(100/6,color='#444444',linestyle='--',linewidth=1)
ax.set(xticks=range(4),xticklabels=recipe_labels,ylim=(0,105),ylabel='Balanced test accuracy (%)',
       title='Representation and training-length ablations · identical held-out rows')
ax.grid(axis='y',alpha=.15);fig.tight_layout();save('quality_ablations')
table(recipe_rows,{'Balanced accuracy %':'{:.2f}'.format,'Mean test log loss':'{:.4f}'.format,
                   'Median complete attempt s':'{:.3f}'.format})
display(Markdown('Bars average training seeds; dots are individual seed results, not confidence intervals. '
 'The PCA-to-LDA comparison changes the representation and its use of training labels. '
 'It cannot attribute accuracy gains to GroupMemory. The representation recipes were chosen before the first test run; '
 'the common optimizer was subsequently repaired using training/validation-only numerical checks. All four ablations use the same repaired optimizer; original PCA names the encoding, not the old optimizer. These are retests of the same held-out rows.'))
'''

LEARNING=r'''
fig,axes=plt.subplots(1,2,figsize=(12.4,4.5))
for method,linestyle in [('group_spectral','-'),('frozen_quantum','--')]:
    selected=[item for item in data['learning'] if item['condition']==main and item['method']==method]
    if not selected:continue
    steps=sorted(set.intersection(*[{item['step'] for item in row['trajectory']} for row in selected]))
    for axis,field in zip(axes,('training_regularized_log_loss','validation_log_loss')):
        values=[np.mean([next(item[field] for item in row['trajectory'] if item['step']==step)
                        for row in selected]) for step in steps]
        x=np.array(steps)-1 if field.startswith('training') else np.array(steps)
        axis.plot(x,values,color=colors[method],linestyle=linestyle,linewidth=2,label=labels[method])
for axis,title in zip(axes,('Training loss + head L2','Validation cross-entropy')):
    axis.set(title=title,xlabel='Completed Adam updates',ylabel='Mean loss across seeds',ylim=(0,None))
    axis.grid(alpha=.15);axis.legend(frameon=False)
fig.tight_layout();save('main_learning_curves')
display(Markdown('One timing repeat per seed contributes to these curves. Training loss is measured '
 'before each update and includes head regularization; validation loss is measured after updates. '
 'Minimum validation loss selects each final checkpoint. The fixed 1,000-update budget does not prove convergence.'))
joint=mainrows('group_spectral').set_index('seed');fixed=mainrows('frozen_quantum').set_index('seed')
common=sorted(set(joint.index)&set(fixed.index))
fig,axes=plt.subplots(1,2,figsize=(10.8,4.3))
for seed in common:
    axes[0].plot([0,1],[100*joint.loc[seed,'balanced_accuracy'],100*fixed.loc[seed,'balanced_accuracy']],
                 color='#9AA3AC',linewidth=1,marker='o',markersize=5)
    axes[1].plot([0,1],[joint.loc[seed,'runtime_s'],fixed.loc[seed,'runtime_s']],
                 color='#9AA3AC',linewidth=1,marker='o',markersize=5)
for axis in axes:
    axis.set_xticks([0,1],['Train quantum angles','Freeze quantum angles'])
    axis.set_xlim(-.2,1.2);axis.grid(axis='y',alpha=.15)
axes[0].set(title='Does training the angles improve accuracy?',ylabel='Balanced accuracy (%)',ylim=(0,100))
axes[1].set(title='Cost of the trained-angle model',ylabel='Complete attempt seconds',ylim=(0,None))
fig.tight_layout();save('frozen_angle_comparison')
table([{'Seed':seed,'Trained balanced %':100*joint.loc[seed,'balanced_accuracy'],
        'Frozen balanced %':100*fixed.loc[seed,'balanced_accuracy'],
        'Difference pp':100*(joint.loc[seed,'balanced_accuracy']-fixed.loc[seed,'balanced_accuracy']),
        'Trained s':joint.loc[seed,'runtime_s'],'Frozen s':fixed.loc[seed,'runtime_s']}
       for seed in common],{'Trained balanced %':'{:.2f}'.format,'Frozen balanced %':'{:.2f}'.format,
         'Difference pp':'{:+.2f}'.format,'Trained s':'{:.3f}'.format,'Frozen s':'{:.3f}'.format})
'''

AUDITED=r'''
comparisons=data['tables'].get('comparisons_all_overhead',[])
if not comparisons:raise ValueError('Primary paired comparisons require audited parent-loop timing')
display(Markdown('The next table is computed from saved paired results and checked alongside the independent audit. '
 'The primary clock is the parent-loop interval, which already includes its worker and journal/checkpoint work. '
 'The runtime criterion requires at least five complete paired seeds, both repeats, '
 'every seed median faster, and median saving of at least 5%. A useful observed win '
 'also requires no lower point accuracy on every paired seed. This is a descriptive gate, '
 'not a significance test or statistical noninferiority result.'))
table([{key.replace('_',' '):value for key,value in row.items()} for row in comparisons])
rows=[]
for method in ('classical_logistic','classical_rbf','classical_mlp'):
    records=[item for item in data['classical'] if item['condition']==main and item['method']==method]
    for record in records:
        scores={item['view']:item['validation_metrics']['log_loss'] for item in record['candidates']}
        rows.append({'Method':labels[method],'Seed':record['seed'],'Selected view':record['selected_view'],
                     'Angle-view validation loss':scores['angles'],'Full561 validation loss':scores['full561'],
                     'LDA axes validation loss':scores.get('lda_axes',float('nan'))})
table(rows,{'Angle-view validation loss':'{:.4f}'.format,'Full561 validation loss':'{:.4f}'.format,
            'LDA axes validation loss':'{:.4f}'.format})
display(Markdown('Each classical family is offered three views: the exact supervised angle representation '
 ', all 561 standardized features, and the uncompressed five LDA axes. All three fits, '
 'view transformations and validation predictions count in runtime. '
 'The test set selects neither the feature view nor hyperparameters.'))
'''

TIMING=r'''
timing=data['timing']
if timing is None:
    display(Markdown('**Whole-study timing receipt not yet available. Per-method process clocks remain visible.**'))
else:
    rows=[]
    for name,receipt in timing.get('phases',{}).items():
        value=receipt.get('seconds') if isinstance(receipt,dict) else receipt
        if isinstance(value,(int,float)):rows.append({'Phase':name,'Seconds':value})
    for key in ('sum_attempt_process_s','sum_attempt_parent_loop_s','measured_parent_loop_overhead_s',
                'campaign_external_wall_s','campaign_setup_gap_and_remaining_s','parent_journal_overhead_s',
                'search_recorded_inner_s','common_acquisition_components_s',
                'rejected_campaign_external_wall_s','stability_search_process_wall_s'):
        if key in timing:rows.append({'Phase':key,'Seconds':timing[key]})
    table(rows,{'Seconds':'{:.3f}'.format})
    display(Markdown('Each method clock includes fresh interpreter startup/imports, data verification '
      'and reads, train-only transforms, compilation/calibration/checks, training, validation selection, '
      'one final test prediction, JSON serialization and shutdown. Main runtime bars show the enclosing parent-loop interval, including the worker and '
      'result journal, checkpoint and progress writes. Sidecar/terminal writes and campaign setup '
      'remain in separately reported invocation/campaign remainder. Search, preflight and orchestration '
      'are study-level costs and are not silently omitted. Campaign wall already includes its workers: '
      'overlapping clocks must not be summed.'))
    if timing.get('search_import_wall_unmeasured'):
        display(Markdown('The recorded development search is an after-import inner clock; its import '
          'wall time was not captured. Any whole-study sum of recorded components is therefore a '
          'partial accounting, not a complete wall-clock claim.'))
    display(Markdown('The original 29.555855s acquisition figure sums recorded download/extraction/'
      'parsing/NPZ-write components. It is not a complete acquisition wall clock. Package installation, '
      'manual coordination and the dataset authors’ original feature extraction are outside those measurements.'))
    if timing.get('comparison_scope'):display(Markdown(str(timing['comparison_scope'])))
ledger=data.get('study_cost_ledger')
if ledger:
    display(Markdown(f"**Partial recorded study components: {ledger['recorded_nonoverlapping_components_sum_s']:.3f}s.** "
      "This includes the rejected initial run and its preparation, numerical stability pilots, the accepted campaign phases, "
      "the recorded inner representation search and acquisition components. It is not complete elapsed study wall time."))
    table([{'Component':r['component'],'Seconds':r['seconds'],'Source':r['source'],'Scope':r['scope']}
           for r in ledger['recorded_nonoverlapping_components']],{'Seconds':'{:.3f}'.format})
    display(Markdown(str(ledger['interpretation'])))
    display(Markdown('Nested attempt/process/parent-loop timers are excluded from that additive ledger. '
      'The focused test overlapping preflight is also excluded. Reporting and packaging receipts stay separate; '
      'unmeasured setup, development time and between-phase gaps are not silently treated as zero.'))
    separate=ledger.get('reporting_helper_costs_separate',{})
    if separate:
        table([{'Separate reporting/helper receipt':name,'Recorded clocks':json.dumps(value,sort_keys=True)}
               for name,value in separate.items()])
'''

REPAIR=r'''
cfg=data['conditions'][main]
display(Markdown(f"The accepted rerun uses the same full-batch Adam settings across evaluators: "
 f"learning rate **{cfg.get('learning_rate')}**, epsilon **{cfg.get('adam_epsilon',cfg.get('epsilon','recorded in raw configuration'))}**. "
 "The tolerance remains **1e−10**; no rounding is used to make outputs agree."))
display(Markdown('The original 100-attempt run completed, but its full training-trajectory audit failed. '
 'Its timings and accuracy are preserved as **rejected evidence**, excluded from every performance table here. '
 'Tiny evaluation differences grew during repeated Adam updates; validation-only pilots checked evaluators '
 'at identical parameters and tested common optimizer settings. The accepted rerun still has to pass the complete audit. '
 'This is a numerical repair and retest of the same already evaluated holdout, not a fresh external confirmation.'))
rows=[]
for receipt in data.get('stability',[]):
    for row in receipt['records']:
        rows.append({'Pilot receipt':receipt['receipt'],'Seed':row['seed'],'Adam epsilon':row['epsilon'],
          'Learning rate':row['learning_rate'],'Methods':' / '.join(row['methods']),
          'Status':row['status'],'Updates checked':row['completed_steps'],
          'Raw trajectory max error':row['max_error']})
if rows:table(rows,{'Raw trajectory max error':'{:.3g}'.format})
repair=data.get('numerical_repair',{})
if repair:
    display(Markdown(str(repair.get('interpretation',''))))
    pilot=repair.get('production_pilot',{})
    if pilot:
        display(Markdown(f"The production-code validation-only pilot completed **{pilot['attempts']} methods** "
          f"with audit **{pilot['status']}** and maximum matched-trajectory error **{pilot['max_matching_error']:.3g}**. "
          "It covers one fragile seed; the complete final audit supplies the remaining coverage."))
    original=repair.get('original_campaign',{})
    search=repair.get('exploratory_search',{})
    if original and search:
        display(Markdown(f"The rejected first campaign cost **{original['external_wall_s']:.3f}s**, "
          f"and the stability search cost **{search['external_process_wall_s']:.3f}s** of measured child-process wall. "
          "These costs remain separate from the accepted method comparisons."))
display(Markdown('Raw failed trajectories, original frozen source, pilot failures and exact trace hashes '
 'are retained separately. Search/pilot wall time and the rejected original run are study costs, '
 'not charged repeatedly to each final method.'))
'''

COVERAGE=r'''
table(data['coverage'])
if data['failures']:
    table([{key:value for key,value in row.items() if key!='config'} for row in data['failures']])
else:display(Markdown('No missing, failed or timed-out attempts appear in the supplied frozen plan.'))
table([{'Package':name,'Version':version} for name,version in data['environment']['packages'].items()])
display(Markdown(f"Platform: `{data['environment']['platform']}`. One computational thread per fresh worker. "
 f"The embedded snapshot records **{sum('/attempts/' in key for key in data['attempt_sha256'])}** attempt hashes, "
 f"**{sum('/attempt_costs/' in key for key in data['attempt_sha256'])}** parent-loop sidecar hashes and "
 f"**{len(data['source_hashes'])}** frozen source hashes. Snapshot SHA256: `{SNAPSHOT_SHA256}`."))
display(Markdown('Re-running this notebook regenerates displays from embedded evidence only. '
 'The accompanying audit, CSVs, timing receipts and raw attempt records are the reproducibility artifacts.'))
'''


def notebook(payload):
    text=json.dumps(payload,sort_keys=True,separators=(',',':'),allow_nan=False)
    digest=hashlib.sha256(text.encode()).hexdigest()
    md=nbformat.v4.new_markdown_cell;code=nbformat.v4.new_code_cell
    cells=[md('# Improved sensor learning: accuracy and complete runtime\n\n'
              'A saved-data comparison of the same factorized quantum model under GroupMemory, '
              'equally informed Qiskit and direct classical differentiation, with classical learners '
              'and fixed-angle controls. No experiment runs when this notebook is opened or rerun.'),
           code('SNAPSHOT_JSON = '+repr(text)+'\nSNAPSHOT_SHA256 = '+repr(digest)+'\n'+SETUP),
           md('## Observed results'),code(HEADLINE),
           md('## Numerical repair and the unchanged correctness check'),code(REPAIR),
           md('## What changed and what stayed matched\n\n'
              'The frozen main recipe uses 512 training examples, 128 subject-disjoint validation '
              'examples and 1,000 full-batch Adam updates. Training-only shrinkage LDA maps the '
              '561 public sensor features to at most five supervised axes. Those standardized axes '
              'are repeated in a fixed pattern across 16 angle inputs, then mapped by '
              r'$x=\pi/2+0.5\arctan(z)$.'+' This is a classical label-informed transformation, '
              'not 16 independent LDA dimensions. The five LDA axes can already carry strong class information.\n\n'
              'The circuit still has 16 independent trainable angles in eight two-qubit patches, '
              'with no entanglement between patches. A two-qubit device could evaluate them sequentially. '
              'A jointly trained six-class softmax head combines the eight local mean-Z features.\n\n'
              'GroupMemory and Qiskit receive identical local factorization, response support, cached '
              'diagonal operators, input identities, cache lifetime and strict off-grid checks. '
              'They evaluate the same model; faster response reuse cannot itself improve accuracy. '
              'The same-model adjoint and frozen-angle controls expose ordinary classical alternatives.\n\n'
              'Representation selection used only development training/validation data. The final '
              'test set contains 256 fixed official-test windows, originally excluding previously evaluated '
              'rows and their immediate same-subject neighbors. Its nine subjects are the same '
              'official held-out subjects used earlier. The numerical repair reruns these same rows after the original failed campaign; '
              'they are neither newly unseen rows nor an independent cohort. '
              'Five training seeds and two timing repeats do not create new test populations.'),
           md('## Main seven-method comparison'),code(MAINFIGURE),
           md('## Accuracy ablations'),code(ABLATIONS),
           md('## Learning curves and the frozen-angle control'),code(LEARNING),
           md('## Audited comparisons and classical feature views'),code(AUDITED),
           md('## Whole-study and method timing'),code(TIMING),
           md('## Coverage and reproducibility'),code(COVERAGE),
           md('## Interpretation limits\n\n'
              'This is ideal CPU simulation. No QPU, noise model, shot sampling, queue delay or '
              'hardware speed advantage is measured. Matching observed point accuracy is not '
              'a statistical equivalence or noninferiority claim. The same fixed test rows and '
              'overlapping development subjects require descriptive interpretation. Any gain '
              'from LDA belongs to the complete hybrid recipe; frozen-angle and classical controls '
              'show whether training the quantum angles contributes further.\n\n'
              'Source: [GroupMemory repository](https://github.com/BoredDuffa/group-memory-qml). '
              'Data: [UCI smartphone activity recognition](https://archive.ics.uci.edu/dataset/240/'
              'human+activity+recognition+using+smartphones), Reyes-Ortiz et al. (2013), '
              '[DOI 10.24432/C54S4K](https://doi.org/10.24432/C54S4K). The current UCI listing and '
              'older bundled README give different license statements; provenance retains both. '
              'Raw sensor data is not redistributed.')]
    nb=nbformat.v4.new_notebook(cells=cells,metadata={
        'kernelspec':{'name':'eight-qml','display_name':'Python · saved-data analysis','language':'python'},
        'language_info':{'name':'python'},'snapshot_sha256':digest})
    for cell in nb.cells:
        if cell.cell_type=='code':cell.metadata['jupyter']={'source_hidden':True}
    return nb,digest


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign',type=Path,required=True)
    parser.add_argument('--extra-campaign',type=Path,action='append',default=[])
    parser.add_argument('--evidence-dir',type=Path)
    parser.add_argument('--outputdir',type=Path)
    parser.add_argument('--publicdir',type=Path)
    parser.add_argument('--main-condition')
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args();started=time.perf_counter()
    campaign=args.campaign.resolve();evidence=(args.evidence_dir or campaign.parent).resolve()
    output=(args.outputdir or campaign.parent).resolve();output.mkdir(parents=True,exist_ok=True)
    payload=snapshot([campaign,*[p.resolve() for p in args.extra_campaign]],evidence,args.main_condition)
    nb,digest=notebook(payload);target=output/'Improved_sensor_benchmark.ipynb'
    if args.execute:
        if payload['audit'] is None:raise RuntimeError('Execution requires the independent audit receipt')
        from nbclient import NotebookClient
        from nbconvert import HTMLExporter
        from traitlets.config import Config
        os.environ['JUPYTER_PATH']=str(WORK/'eight-qml-kernel')+os.pathsep+os.environ.get('JUPYTER_PATH','')
        NotebookClient(nb,timeout=180,kernel_name='eight-qml',
                       resources={'metadata':{'path':str(output)}}).execute()
        cfg=Config();cfg.HTMLExporter.exclude_input=True
        cfg.HTMLExporter.exclude_input_prompt=True;cfg.HTMLExporter.exclude_output_prompt=True
        html,_=HTMLExporter(config=cfg).from_notebook_node(nb)
        (output/'Improved_sensor_benchmark.html').write_text(html)
        nbformat.write(nb,REPO/'examples'/'improved_sensor_benchmark.ipynb')
        if args.publicdir:
            args.publicdir.mkdir(parents=True,exist_ok=True)
            (args.publicdir/'report_snapshot.json').write_text(json.dumps(payload,indent=2,allow_nan=False)+'\n')
    nbformat.write(nb,target)
    receipt=dict(status='EXECUTED' if args.execute else 'DRAFT_UNEXECUTED',
        snapshot_sha256=digest,notebook_sha256=sha(target),seconds=time.perf_counter()-started,
        successful=payload['successful'],planned=payload['planned'],
        scope='Saved-data snapshot, notebook and report rendering only')
    (output/'report_build_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':main()
