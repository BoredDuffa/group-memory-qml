"""Package the rejected initial sensor run without rerunning any experiment.

Exact input bytes are retained. Both archives have an internal SHA256 manifest.
No raw UCI data are included. Source is read from the frozen Git commit, never
from the mutable checkout. The code rejects common private-path/secret markers.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import zipfile

BASE=Path(__file__).resolve().parent.parent
REVISION='a0f8cb5fc67845c0be30ea08cc51dac782b8ac96'


def digest(data):return hashlib.sha256(data).hexdigest()
def encoded(value):return (json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
def read(path):return json.loads(path.read_text())


def privacy_check(name,data):
    if Path(name).is_absolute() or '..' in Path(name).parts:
        raise ValueError('Unsafe archive member name')
    patterns=(rb'/Users/[^\s"<>]+',rb'/home/[^\s"<>]+',rb'/workspace/[^\s"<>]+',
              rb'[A-Z]:\\Users\\',rb'-----BEGIN (?:OPENSSH|RSA|EC|PRIVATE).*KEY-----',
              rb'gh[pousr]_[A-Za-z0-9]{25,}',rb'github_pat_[A-Za-z0-9_]{25,}',
              rb'sk-[A-Za-z0-9]{25,}')
    if any(re.search(pattern,data) for pattern in patterns):
        raise ValueError(f'Potential private path/secret marker in archive member {name}; no content printed')


def write_archive(path,payload):
    hashes={name:digest(data) for name,data in sorted(payload.items())}
    payload=dict(payload)
    payload['SHA256SUMS.json']=encoded(dict(algorithm='SHA256',scope='Every archive member except this checksum manifest',files=hashes))
    temporary=path.with_suffix(path.suffix+'.tmp')
    with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
        for name,data in sorted(payload.items()):
            privacy_check(name,data)
            info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644<<16
            archive.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=1)
    temporary.replace(path)
    with zipfile.ZipFile(path) as archive:
        names=archive.namelist()
        if len(set(names))!=len(names):raise ValueError('Duplicate archive member')
        manifest=json.loads(archive.read('SHA256SUMS.json'))['files']
        if set(names)!=(set(manifest)|{'SHA256SUMS.json'}):raise ValueError('Archive inventory mismatch')
        for name,expected in manifest.items():
            data=archive.read(name)
            if digest(data)!=expected:raise ValueError('Archive checksum mismatch')
            privacy_check(name,data)
    return dict(file=path.name,bytes=path.stat().st_size,sha256=digest(path.read_bytes()),
                members=len(payload),checksummed_members=len(hashes),internal_manifest_verified=True,
                privacy_scan_passed=True)


def source_snapshot(repo,revision,config):
    resolved=subprocess.check_output(['git','rev-parse',revision],cwd=repo,text=True).strip()
    if resolved!=REVISION:raise ValueError('Rejected archive must use the original frozen source commit')
    prefixes=['src','tests','benchmarks','docs','pyproject.toml','LICENSE','README.md','CONTRIBUTING.md']
    raw=subprocess.check_output(['git','archive','--format=zip',resolved,*prefixes],cwd=repo)
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        payload={info.filename:archive.read(info) for info in archive.infolist() if not info.is_dir()}
    checked={}
    for relative,expected in config['source_hashes'].items():
        name='src/group_memory_qml/'+relative
        if name not in payload or digest(payload[name])!=expected:
            raise ValueError(f'Frozen source hash mismatch for {relative}')
        checked[relative]=expected
    payload['SNAPSHOT.json']=encoded(dict(status='REJECTED_INITIAL_SOURCE',revision=resolved,
        verified_campaign_source_hashes=checked,verified_source_file_count=len(checked),
        scope='Exact Git bytes for source, tests, benchmark plans, documentation and install/license metadata. Prior results, datasets, virtual environments, Git internals and unrelated notebooks are excluded.',
        warning='This is the original epsilon1e-8 run source. Its completed long-training campaign failed strict cross-engine trajectory agreement; equal accuracy does not validate performance claims.'))
    return payload,len(checked)


def package(input_dir,output,repo):
    config=read(input_dir/'campaign/config.json');audit=read(input_dir/'audit.json')
    revision=read(input_dir/'code_revision.json')
    if revision['revision']!=REVISION:raise ValueError('Unexpected original source revision')
    attempts=sorted((input_dir/'campaign/attempts').glob('[0-9][0-9][0-9][0-9][0-9].json'))
    if len(attempts)!=100 or len(config['plan'])!=100 or audit.get('status')!='FAIL':
        raise ValueError('Expected the completed, rejected100-attempt initial campaign')
    if audit.get('max_matching_error',0)<=1e-10:
        raise ValueError('Expected the original strict-trajectory failure')
    payload={}
    for path in sorted((input_dir/'campaign').rglob('*')):
        if not path.is_file():continue
        relative=path.relative_to(input_dir).as_posix()
        if '.worker.' in path.name:raise ValueError('Unexpected unfinished worker artifact')
        payload[relative]=path.read_bytes()
    selected=['audit.json','code_revision.json','analysis_protocol.md','selection_freeze.json',
        'final_holdout_manifest.json','stability_diagnosis.json','summary.csv','seed_medians.csv',
        'comparisons.csv','summary_audit_gate.json','timing_accounting.json',
        'summary_receipt_audit_gated.json','main.log','resume_verification.json',
        'audit_hash_convention_repair.json']
    for name in selected:
        path=input_dir/name
        if path.exists():payload[name]=path.read_bytes()
    for path in sorted(input_dir.glob('*_wall.json')):
        payload['cost_receipts/'+path.name]=path.read_bytes()
    for name in ['initial_preflight.log','preflight.log']:
        if (input_dir/name).exists():payload['preflight/'+name]=(input_dir/name).read_bytes()
    old_comparisons=input_dir/'comparisons_rejected_before_audit_gate.csv'
    if not old_comparisons.exists():raise ValueError('Preserved original ungated comparisons are missing')
    payload['rejected_ungated/comparisons.csv']=old_comparisons.read_bytes()
    payload['rejected_ungated/rejection_receipt.json']=(input_dir/'comparisons_rejected_before_audit_gate.json').read_bytes()
    original_receipt=input_dir/'summary_receipt.json'
    payload['rejected_ungated/original_summary_receipt.json']=original_receipt.read_bytes()
    original=read(original_receipt)
    # Exact numerical rows from the original receipt; reconstructed CSV syntax
    # is explicitly identified and is not claimed to be original CSV bytes.
    stream=io.StringIO(newline='');writer=csv.DictWriter(stream,fieldnames=list(original['summary'][0]))
    writer.writeheader();writer.writerows(original['summary'])
    payload['rejected_ungated/summary_reconstructed_from_original_receipt.csv']=stream.getvalue().encode()
    payload['rejected_ungated/timing_accounting_from_original_receipt.json']=encoded(original['timing'])
    for name in ['comparisons.csv']:
        for row in csv.DictReader(io.StringIO(payload[name].decode())):
            if row['eligible_runtime_win']!='False' or row['useful_observed_win']!='False':
                raise ValueError('Top-level rejected comparisons must have all qualifying win flags disabled')
    # Verify original checkpoint-to-attempt links without modifying any bytes.
    manifest=read(input_dir/'campaign/checkpoints/manifest.json')
    cp_path=input_dir/'campaign/checkpoints'/manifest['latest']
    if digest(cp_path.read_bytes())!=manifest['latest_sha256']:raise ValueError('Original latest-checkpoint hash mismatch')
    checkpoint=read(cp_path)
    for name,expected in checkpoint['journal_sha256'].items():
        if digest((input_dir/'campaign/attempts'/name).read_bytes())!=expected:raise ValueError('Original attempt journal hash mismatch')
    for i,path in enumerate(attempts):
        row=read(path)
        if row['spec']!=config['plan'][i] or row['source_hashes']!=config['source_hashes']:
            raise ValueError('Original attempt plan/source identity mismatch')
        if 'validation_vector' not in row:raise ValueError('Original full trajectory is missing')
    original_hashes={path.relative_to(input_dir).as_posix():digest(path.read_bytes()) for path in attempts}
    payload['REJECTION.json']=encoded(dict(status='REJECTED',revision=REVISION,attempts=100,
        audit_status='FAIL',maximum_cross_engine_trajectory_difference=audit['max_matching_error'],
        required_tolerance=1e-10,original_audit_errors=audit['errors'],original_attempt_sha256=original_hashes,
        original_audit_sha256=digest((input_dir/'audit.json').read_bytes()),
        evidence_policy='All100 full-vector attempt JSON files and original configuration, status and checkpoints are preserved byte-for-byte. Reconstructed summary CSV is explicitly named. Top-level comparisons enforce audit rejection; rejected_ungated files preserve the old invalid flags only as historical evidence.',
        conclusion='Identical selected-checkpoint test accuracy did not rescue failed full-trajectory equivalence. No qualifying runtime or useful-win claim from this campaign is valid. Do not pool these timings with any repaired campaign.',
        heldout_policy='This run evaluated the fixed256-row holdout. Later numerical-correctness recovery uses an already evaluated holdout, not a newly untouched test set.',
        raw_dataset_included=False))
    payload['README_REJECTED.md']=b'''# Rejected initial improved-sensor run

This archive preserves100 completed attempts from source a0f8cb5fc67845c0be30ea08cc51dac782b8ac96. The independent audit is FAIL.

Full cross-engine trajectories differed by up to0.03408229468145725 against the unchanged1e-10 requirement. A separate UTC-versus-monotonic timing-enclosure check also failed. Identical final classification accuracy did not rescue those failures. No qualifying performance or useful-win claim from this run is valid.

All original full-vector attempt JSON bytes are preserved in the four rejected_attempts_*.zip archives; configuration, status, authorization, environment, checkpoint and audit bytes are preserved here. Extract the metadata and all four attempt archives into one directory to restore the complete original campaign tree. The original checksum links are verified. Top-level CSVs use the later strict audit gate. The rejected_ungated folder preserves the old invalid win flags and original summary receipt for transparency; those flags must never be presented as accepted results. Its explicitly named reconstructed summary CSV reproduces the original receipt values, not a claim about original CSV bytes.

Use rejected_source_snapshot.zip for exact frozen code. Its32 campaign source hashes are verified against the original configuration. Every ZIP has an internal SHA256SUMS.json manifest. ATTEMPT_ARCHIVES.json identifies all four full-vector shards and their archive hashes. No raw sensor dataset, private paths or secrets are included.

The test set was256 class-balanced rows excluding previously evaluated rows and immediate same-subject neighbors, but it uses existing test subjects. Any subsequent correctness-recovery rerun reuses this evaluated holdout. Keep this failed run and its costs separate from repaired-run timings; retain its cost in total study accounting. CPU simulation, supervised classical LDA, five intrinsic representation axes and independent two-qubit patches do not establish a QPU or practical quantum advantage.
'''
    source,n_source=source_snapshot(repo,REVISION,config)
    output.mkdir(parents=True,exist_ok=True)
    source_receipt=write_archive(output/'rejected_source_snapshot.zip',source)
    attempt_receipts=[]
    attempt_names=sorted(name for name in payload if name.startswith('campaign/attempts/'))
    if len(attempt_names)!=100:raise ValueError('Unexpected attempt archive inventory')
    for start in range(0,100,25):
        chosen=attempt_names[start:start+25]
        subset={name:payload.pop(name) for name in chosen}
        subset['SHARD.json']=encoded(dict(status='REJECTED_INITIAL_ATTEMPT_SHARD',
            first_index=start,last_index=start+24,attempt_count=25,
            metadata_archive='rejected_initial_run.zip',source_archive='rejected_source_snapshot.zip',
            warning='Partial rejected evidence only. Extract all four rejected_attempts_*.zip shards plus metadata together. Full trajectories are preserved unchanged; no performance claims are valid.'))
        part=write_archive(output/f'rejected_attempts_{start:05d}_{start+24:05d}.zip',subset)
        if part['bytes']>=50_000_000:raise ValueError('Attempt shard exceeds publication size target')
        attempt_receipts.append(part)
    payload['ATTEMPT_ARCHIVES.json']=encoded(dict(attempt_count=100,archives=attempt_receipts,
        extraction='Extract all four archives and this metadata archive into the same directory. They reconstruct campaign/attempts/00000.json through00099.json alongside original config/status/checkpoints.',
        scope='Exact original full-vector JSON bytes, with per-file and per-archive SHA256 integrity.'))
    rejected_receipt=write_archive(output/'rejected_initial_run.zip',payload)
    receipt=dict(status='PACKAGED_REJECTED_EVIDENCE',original_revision=REVISION,
        original_attempts=100,verified_original_source_hashes=n_source,
        original_audit_sha256=digest((input_dir/'audit.json').read_bytes()),
        archives=[rejected_receipt,source_receipt,*attempt_receipts],raw_dataset_included=False,
        raw_attempts_unchanged=True,original_checkpoint_journal_verified=True)
    (output/'rejected_package_receipt.json').write_bytes(encoded(receipt))
    return receipt


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=BASE/'outputs/Improved_sensor_benchmark')
    parser.add_argument('--output',type=Path,default=BASE/'outputs/Improved_sensor_stable')
    parser.add_argument('--repo',type=Path,default=BASE/'group-memory-qml')
    args=parser.parse_args()
    print(json.dumps(package(args.input,args.output,args.repo),indent=2))


if __name__=='__main__':main()
