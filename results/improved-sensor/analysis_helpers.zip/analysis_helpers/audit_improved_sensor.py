"""Independent saved-data audit; never imports project code or runs a model.

Usage: python work/audit_improved_sensor.py --campaign outputs/.../campaign \
  --output outputs/.../audit.json --repo group-memory-qml

Only JSON/source reads, NumPy array arithmetic and optional verified dataset
reads occur. This checks optimizer replay, result metrics, split/source links,
controller receipts and paired numerical agreement. It does not independently
recompute quantum gradients or prove that logged wall clocks are trustworthy.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import random
import sys
import time

import numpy as np

QML = ("group_spectral", "qiskit_response", "classical_adjoint")
METHODS = (*QML, "frozen_quantum", "classical_logistic", "classical_rbf", "classical_mlp")
TOL = 1e-10


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def arrays_sha(*arrays):
    digest = hashlib.sha256()
    for array in arrays:
        array = np.ascontiguousarray(array)
        digest.update(json.dumps({"shape": array.shape, "dtype": array.dtype.str}).encode())
        digest.update(array.tobytes())
    return digest.hexdigest()


def loader_arrays_sha(*arrays):
    """Loader/provenance hash recipe; distinct from trainer diagnostic hashes."""
    digest = hashlib.sha256()
    for array in arrays:
        a = np.ascontiguousarray(array)
        digest.update(str(a.shape).encode())
        digest.update(str(a.dtype).encode())
        digest.update(a.tobytes())
    return digest.hexdigest()


def metrics(labels, probabilities):
    labels, p = np.asarray(labels, dtype=int), np.asarray(probabilities, dtype=float)
    if p.shape != (len(labels), 6) or not np.isfinite(p).all() or np.any(p < 0):
        raise ValueError("Invalid probabilities")
    if np.max(np.abs(p.sum(axis=1)-1)) > TOL:
        raise ValueError("Probabilities do not sum to one")
    predictions = p.argmax(axis=1)
    confusion = np.zeros((6, 6), dtype=int)
    for label, predicted in zip(labels, predictions):
        confusion[label, predicted] += 1
    supports = confusion.sum(axis=1)
    if np.any(supports == 0):
        raise ValueError("Missing class")
    return dict(accuracy=float(np.mean(predictions == labels)),
                balanced_accuracy=float(np.mean(np.diag(confusion)/supports)),
                log_loss=float(-np.mean(np.log(np.clip(p[np.arange(len(labels)), labels], 1e-15, 1)))),
                confusion_matrix=confusion.tolist(), class_support=supports.tolist())


def plan_from_config(config):
    rng = random.Random(20261025)
    blocks = [(c, s, r) for c in config["conditions"] for s in config["seeds"]
              for r in range(config["repeats"])]
    rng.shuffle(blocks)
    plan = []
    for condition, seed, repeat in blocks:
        methods = list(condition.get("methods", METHODS))
        rng.shuffle(methods)
        for method in methods:
            plan.append(dict(condition=condition["id"], experiment=condition["experiment"],
                config=condition.get("config", {}), seed=seed, repeat=repeat, method=method))
    return plan


def independently_selected_rows(data, seed, n_train, n_validation):
    """Recreate the declared class/subject round-robin sampling without package code."""
    from itertools import zip_longest
    subjects, labels = data["subjects_train"], data["y_train"]
    rng = np.random.default_rng(np.random.SeedSequence([seed, 1001]))
    validation_subjects = np.sort(rng.permutation(np.unique(subjects))[:5])
    mask = np.isin(subjects, validation_subjects)
    result = {}
    for split, eligible, size, salt in (("train", ~mask, n_train, 2001),
                                        ("validation", mask, n_validation, 2002)):
        rng = np.random.default_rng(np.random.SeedSequence([seed, salt]))
        by_class = {}
        for label in range(6):
            rows = np.flatnonzero(eligible & (labels == label))
            order = rng.permutation(np.unique(subjects[rows]))
            subject_rows = [rng.permutation(rows[subjects[rows] == subject]).tolist() for subject in order]
            by_class[label] = [row for turn in zip_longest(*subject_rows) for row in turn if row is not None]
        class_order = rng.permutation(6)
        ordered = [row for turn in zip_longest(*(by_class[label] for label in class_order))
                   for row in turn if row is not None]
        result[split] = ordered[:size]
    return result, validation_subjects.tolist()


class Audit:
    def __init__(self):
        self.errors = []
        self.checks = Counter()
        self.max_adam_error = 0.0
        self.max_matching_error = 0.0

    def check(self, condition, name, detail=""):
        self.checks[name] += 1
        if not condition:
            self.errors.append(f"{name}: {detail}")
        return bool(condition)

    def close(self, actual, expected, name, detail="", tolerance=TOL):
        a, b = np.asarray(actual, dtype=float), np.asarray(expected, dtype=float)
        good_shape = a.shape == b.shape
        error = float(np.max(np.abs(a-b))) if good_shape and a.size else (0.0 if good_shape else float("inf"))
        self.check(good_shape and np.isfinite(a).all() and np.isfinite(b).all() and error <= tolerance,
                   name, f"{detail}; maximum error {error}")
        return error

    def metric(self, reported, calculated, detail):
        for key in ("accuracy", "balanced_accuracy", "log_loss"):
            self.close(reported[key], calculated[key], "recomputed_metrics", detail+"/"+key)
        for key in ("confusion_matrix", "class_support"):
            self.check(reported[key] == calculated[key], "recomputed_metrics", detail+"/"+key)

    def trajectory(self, row, val_labels):
        d, cfg, method = row["diagnostics"], row["config"], row["method"]
        name = f'{row["spec"]["condition"]}/{row["seed"]}/{row["spec"]["repeat"]}/{method}'
        n, steps = cfg["n_qubits"], d["completed_steps"]
        pcount, vcount = n+6*(n//2)+6, cfg["n_validation"]*6
        v = np.asarray(row["validation_vector"], dtype=float)
        width = 2+2*pcount
        expected = pcount+vcount+steps*width+1+pcount+vcount
        if not cfg["validation_only"]:
            expected += cfg["n_test"]*(n//2+6)
        if not self.check(v.shape == (expected,) and np.isfinite(v).all(), "trajectory_vector_layout", name):
            return
        initial, initial_probs = v[:pcount], v[pcount:pcount+vcount].reshape(-1, 6)
        records = v[pcount+vcount:pcount+vcount+steps*width].reshape(steps, width)
        gradients, updates = records[:, 2:2+pcount], records[:, 2+pcount:]
        tail = v[pcount+vcount+steps*width:]
        rng = np.random.default_rng(np.random.SeedSequence([row["seed"], 61527]))
        expected_initial = np.r_[rng.uniform(-.7, .7, n), rng.normal(0, .1, (n//2, 6)).ravel(), np.zeros(6)]
        self.close(initial, expected_initial, "initialization_seed", name, 0)
        self.check(d["validation_vector_layout"]["parameter_count"] == pcount, "parameter_count", name)
        theta_info = d["parameter_training"]
        self.close(theta_info["initial_parameters"], initial, "parameter_receipts", name)
        moment, square = np.zeros(pcount), np.zeros(pcount)
        parameters = initial.copy()
        epsilon = cfg.get("adam_epsilon", 1e-8)
        self.check(np.isfinite(epsilon) and epsilon > 0, "positive_adam_epsilon", name)
        self.close(d["optimizer"]["epsilon"], epsilon, "recorded_adam_epsilon", name, 0)
        previous = initial
        for index, (gradient, updated) in enumerate(zip(gradients, updates), 1):
            moment = .9*moment+.1*gradient
            square = .999*square+.001*gradient**2
            expected_parameters = parameters-cfg["learning_rate"]*(moment/(1-.9**index))/(
                np.sqrt(square/(1-.999**index))+epsilon)
            error = self.close(updated, expected_parameters, "adam_replay", f"{name}/step{index}")
            self.max_adam_error = max(self.max_adam_error, error)
            trace = d["training_trajectory"][index-1]
            self.check(trace["step"] == index, "trajectory_step_order", name)
            self.close(trace["training_regularized_log_loss"], records[index-1, 0], "trajectory_scalars", name)
            self.close(trace["validation_log_loss"], records[index-1, 1], "trajectory_scalars", name)
            self.close(trace["gradient_l2"], np.linalg.norm(gradient), "trajectory_norms", name)
            self.close(trace["parameter_step_l2"], np.linalg.norm(updated-previous), "trajectory_norms", name)
            parameters, previous = updated, updated
        self.close(theta_info["final_parameters"], updates[-1], "parameter_receipts", name)
        self.close(theta_info["displacement"], updates[-1, :n]-initial[:n], "angle_displacement", name)
        self.check(theta_info["moved_parameters"] == int(np.sum(np.abs(updates[-1, :n]-initial[:n]) > 1e-12)),
                   "angle_displacement", name)
        losses = np.r_[d["initial_validation_metrics"]["log_loss"], records[:, 1]]
        selected = int(np.argmin(losses))
        selected_parameters = initial if selected == 0 else updates[selected-1]
        self.check(d["selected_checkpoint_step"] == selected and tail[0] == selected,
                   "minimum_validation_checkpoint", name)
        self.close(tail[1:1+pcount], selected_parameters, "selected_parameters", name)
        self.close(theta_info["selected_parameters"], selected_parameters, "selected_parameters", name)
        self.close(row["validation_metrics"]["log_loss"], losses[selected], "minimum_validation_loss", name)
        best_probs = tail[1+pcount:1+pcount+vcount].reshape(-1, 6)
        if val_labels is not None:
            self.metric(d["initial_validation_metrics"], metrics(val_labels, initial_probs), name+"/initial_validation")
            self.metric(row["validation_metrics"], metrics(val_labels, best_probs), name+"/selected_validation")
        self.check(d["test_evaluations"] == int(not cfg["validation_only"]), "test_evaluated_after_selection_only", name)
        if not cfg["validation_only"]:
            rest = tail[1+pcount+vcount:]
            test_features = rest[:cfg["n_test"]*(n//2)].reshape(-1, n//2)
            test_probabilities = rest[cfg["n_test"]*(n//2):].reshape(-1, 6)
            head = selected_parameters[n:n+(n//2)*6].reshape(n//2, 6)
            logits = test_features @ head + selected_parameters[-6:]
            logits -= logits.max(axis=1, keepdims=True)
            predicted = np.exp(logits)
            predicted /= predicted.sum(axis=1, keepdims=True)
            self.close(test_probabilities, predicted, "final_softmax_reconstruction", name)
            self.close(test_probabilities, d["test_probabilities"], "test_probability_receipts", name)
        else:
            self.check(row["test_metrics"] is None and d["test_probabilities"] is None and "test_labels" not in d,
                       "search_excludes_test", name)
        if method == "frozen_quantum":
            self.close(gradients[:, :n], np.zeros_like(gradients[:, :n]), "frozen_angle_gradients", name, 0)
            self.close(updates[:, :n], np.broadcast_to(initial[:n], (steps, n)), "frozen_angles_unchanged", name, 0)
            self.check(not d["validation_response_strategy"]["warm_once"], "frozen_no_response_warmup", name)
            expected_examples = cfg["n_train"]+cfg["n_validation"]+(0 if cfg["validation_only"] else cfg["n_test"])
            self.check(d["engine"]["evaluated_examples"] == expected_examples, "frozen_features_evaluated_once", name)
        else:
            expected_warm = method in ("group_spectral", "qiskit_response") and cfg["steps"] >= 25
            self.check(d["validation_response_strategy"]["warm_once"] == expected_warm,
                       "matched_validation_warmup", name)
        patience = cfg["early_stopping_patience"]
        stop = cfg["steps"]
        if patience:
            best, stale = losses[0], 0
            for i, value in enumerate(losses[1:], 1):
                if value < best:
                    best, stale = value, 0
                else:
                    stale += 1
                if stale >= patience:
                    stop = i
                    break
        self.check(steps == stop, "completed_optimizer_steps", name)

    def classical(self, row, val_labels):
        d, cfg = row["diagnostics"], row["config"]
        name = f'{row["spec"]["condition"]}/{row["seed"]}/{row["method"]}'
        candidates = d["classical_candidates"]
        expected_views = ["angles", "full561"] + (["lda_axes"] if cfg["representation"].startswith("lda_") else [])
        self.check([c["view"] for c in candidates] == expected_views, "all_classical_views_fit", name)
        chosen = min(range(len(candidates)), key=lambda i: candidates[i]["validation_metrics"]["log_loss"])
        self.check(d["selected_feature_view"] == candidates[chosen]["view"], "classical_validation_selection", name)
        self.check(row["validation_metrics"] == candidates[chosen]["validation_metrics"], "classical_validation_selection", name)
        for field, item in (("candidate_fit_s", "fit_s"), ("candidate_validation_s", "validation_predict_s")):
            self.close(d["timings"][field], sum(c[item] for c in candidates), "all_classical_candidates_charged", name)
        self.check(d["test_evaluations"] == int(not cfg["validation_only"]), "test_evaluated_after_selection_only", name)
        vector = np.asarray(row["validation_vector"])
        count = cfg["n_validation"]*6
        self.check(vector.size == count + (0 if cfg["validation_only"] else cfg["n_test"]*6),
                   "classical_vector_layout", name)
        if val_labels is not None:
            self.metric(row["validation_metrics"], metrics(val_labels, vector[:count].reshape(-1, 6)), name+"/validation")
        if cfg["validation_only"]:
            self.check(row["test_metrics"] is None and d["test_probabilities"] is None and "test_labels" not in d,
                       "search_excludes_test", name)


def source_review(repo, audit):
    root = repo/"src"/"group_memory_qml"
    data_text = (root/"improved_sensor_data.py").read_text()
    tree = ast.parse(data_text)
    embedded = pin = None
    for node in tree.body:
        if isinstance(node, ast.Assign):
            targets = [t.id for t in node.targets if isinstance(t, ast.Name)]
            if "HOLDOUT_MANIFEST_SHA256" in targets:
                pin = ast.literal_eval(node.value)
            if "_FROZEN_HOLDOUT" in targets:
                embedded = json.loads(ast.literal_eval(node.value.args[0]))
    audit.check(embedded is not None and pin is not None, "holdout_source_pin")
    if embedded is not None:
        actual = hashlib.sha256(json.dumps(embedded, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        audit.check(actual == pin, "embedded_holdout_hash", actual)
    # These checks capture a human-reviewed source contract, not formal proof.
    required = {
        "training_only_standardizer": "StandardScaler().fit(raw['train'])",
        "training_only_lda": "LinearDiscriminantAnalysis(n_components=5, solver='eigen', shrinkage='auto').fit(full['train'], labels['train'])",
        "training_only_coordinate_scaler": "StandardScaler().fit(projected['train'])",
        "lda_tiling": "mapping = np.arange(n_features) % 5",
        "shifted_angle_map": "np.pi/2 + angle_scale*np.arctan(x)",
        "original_pca_map": "2*np.arctan(x)",
        "split_subject_seed": "np.random.SeedSequence([seed, 1001])",
        "training_subset_seed": "np.random.SeedSequence([seed, 2001])",
        "validation_subset_seed": "np.random.SeedSequence([seed, 2002])",
        "search_training_members_only": "('X_train', 'y_train', 'subjects_train')",
    }
    for name, text in required.items():
        audit.check(text in data_text, "source_contract_"+name)
    training_text = (root/"improved_sensor_training.py").read_text()
    trainer_contract = {
        "shared_initializer": 'np.random.SeedSequence([seed, 61527])',
        "configured_adam_epsilon": 'np.sqrt(second_moment/(1-0.999**step)) + cfg["adam_epsilon"]',
        "epsilon_recorded": 'epsilon=cfg["adam_epsilon"]',
        "direct_lda_axis_control": 'np.tan((angles - np.pi / 2) / cfg["angle_scale"])',
    }
    for name, text in trainer_contract.items():
        audit.check(text in training_text, "source_contract_"+name)
    return embedded, pin


def verify_attempt_costs(campaign, config, status, paths, audit):
    """Verify independent parent-loop receipts without modifying result hashes."""
    directory = campaign/"attempt_costs"
    manifest_path = directory/"manifest.json"
    required = config.get("attempt_cost_receipt_version", 0) >= 1
    if not required and not manifest_path.exists():
        return dict(available=False, legacy=True)
    if not audit.check(manifest_path.exists(), "attempt_cost_manifest_present"):
        return dict(available=False, legacy=False)
    manifest = read(manifest_path)
    audit.check(manifest["version"] == 1 and manifest["completed_attempts"] == len(paths), "attempt_cost_manifest_identity")
    audit.check(manifest["config_sha256"] == sha(campaign/"config.json"), "attempt_cost_config_hash")
    audit.check(status["attempt_cost_manifest_sha256"] == sha(manifest_path), "terminal_attempt_cost_manifest_hash")
    audit.check(set(manifest["sidecar_sha256"]) == {p.name for p in paths}, "attempt_cost_coverage")
    costs = []
    for i, path in enumerate(paths):
        receipt_path = directory/path.name
        audit.check(receipt_path.exists(), "attempt_cost_sidecar_present", path.name)
        cost, row = read(receipt_path), read(path)
        costs.append(cost)
        audit.check(sha(receipt_path) == manifest["sidecar_sha256"][path.name], "attempt_cost_sidecar_hash", path.name)
        audit.check(cost["version"] == 1 and cost["attempt_index"] == i and cost["spec"] == row["spec"], "attempt_cost_identity", path.name)
        audit.check(cost["result_sha256"] == sha(path) and cost["config_sha256"] == sha(campaign/"config.json"), "attempt_cost_source_links", path.name)
        left, right = cost["loop_start_monotonic_s"], cost["loop_end_monotonic_s"]
        start, end, process_end = row["attempt_start_monotonic_s"], row["attempt_end_monotonic_s"], row["process_end_monotonic_s"]
        audit.check(np.isfinite([left, right, start, end, process_end]).all() and left <= start <= process_end <= end <= right,
                    "parent_loop_encloses_process_and_journal", path.name)
        audit.close(cost["parent_loop_wall_s"], right-left, "parent_loop_duration", path.name, 0)
        audit.close(cost["process_wall_s"], row["process_wall_s"], "sidecar_process_duration", path.name, 0)
        audit.close(cost["pre_launch_parent_s"], start-left, "pre_launch_parent_cost", path.name, 0)
        audit.close(cost["post_process_parent_s"], right-process_end, "post_process_parent_cost", path.name, 0)
        audit.close(cost["parent_overhead_s"], right-left-row["process_wall_s"], "parent_overhead_cost", path.name, 0)
        audit.check(cost["parent_overhead_s"] >= 0, "nonnegative_parent_overhead", path.name)
    audit.close(status["summed_parent_loop_s"], sum(c["parent_loop_wall_s"] for c in costs), "summed_parent_loop_cost", tolerance=1e-6)
    audit.close(status["summed_parent_loop_overhead_s"], sum(c["parent_overhead_s"] for c in costs), "summed_parent_overhead_cost", tolerance=1e-6)
    cursor = status["last_invocation_start_cursor"]
    this_run = costs[cursor:]
    invocation_start = status["last_invocation_start_monotonic_s"]
    invocation_end = status["last_invocation_end_monotonic_s"]
    loop_start = invocation_start+status["last_invocation_setup_s"]
    previous, gaps = loop_start, 0.0
    for cost in this_run:
        audit.check(cost["loop_start_monotonic_s"] >= previous, "serial_parent_loop_receipts")
        gaps += cost["loop_start_monotonic_s"]-previous
        previous = cost["loop_end_monotonic_s"]
    audit.close(status["last_invocation_gap_s"], gaps, "invocation_gap_accounting", tolerance=1e-6)
    audit.close(status["last_invocation_after_loop_s"], invocation_end-previous, "invocation_after_loop_accounting", tolerance=1e-6)
    audit.close(status["last_invocation_loop_s"], sum(c["parent_loop_wall_s"] for c in this_run), "invocation_loop_accounting", tolerance=1e-6)
    audit.close(status["last_invocation_measured_s"], invocation_end-invocation_start, "invocation_total_interval", tolerance=1e-6)
    audit.close(status["last_invocation_measured_s"], sum(status[k] for k in ("last_invocation_setup_s", "last_invocation_loop_s", "last_invocation_gap_s", "last_invocation_after_loop_s")), "invocation_all_costs_reconcile", tolerance=1e-6)
    audit.close(status["last_invocation_parent_remainder_s"], status["last_invocation_gap_s"]+status["last_invocation_after_loop_s"], "invocation_parent_remainder", tolerance=1e-6)
    return dict(available=True, version=1, successful_sidecars=len(costs),
                summed_parent_loop_s=sum(c["parent_loop_wall_s"] for c in costs),
                summed_parent_overhead_s=sum(c["parent_overhead_s"] for c in costs),
                scope="Final status serialization/return additionally charged by enclosing caller timing")


def audit_campaign(campaign, repo, data_dir=None, holdout_path=None):
    started = time.perf_counter()
    audit = Audit()
    config, authorization, status = [read(campaign/name) for name in ("config.json", "authorization.json", "status.json")]
    plan = config["plan"]
    audit.check(plan == plan_from_config(config), "independent_plan_reconstruction")
    expected_deadline = min(authorization["start_unix"]+config["budget_s"], config.get("hard_deadline_unix", float("inf")))
    audit.close(authorization["deadline_unix"], expected_deadline, "immutable_authorization_deadline", tolerance=1e-6)
    audit.check(status["deadline_unix"] == authorization["deadline_unix"], "status_deadline")
    actual_sources = {str(path.relative_to(repo/"src"/"group_memory_qml")): sha(path)
                      for path in sorted((repo/"src"/"group_memory_qml").rglob("*.py"))}
    audit.check(actual_sources == config["source_hashes"], "current_source_matches_frozen_config")
    holdout, holdout_pin = source_review(repo, audit)
    if holdout_path is None:
        options = (campaign/"final_holdout_manifest.json", campaign.parent/"final_holdout_manifest.json")
        holdout_path = next((p for p in options if p.exists()), None)
    if holdout_path is not None:
        audit.check(read(holdout_path) == holdout, "external_holdout_matches_source_pin")
    else:
        audit.check(False, "external_holdout_manifest_present")
    data_dir = Path(data_dir) if data_dir else repo.parent/"work"/"data"/"uci_har"
    data_path = data_dir/"har_features.npz"
    data = None
    search_only = all(spec["config"].get("validation_only", False) for spec in plan)
    dataset_members = ("y_train", "subjects_train") if search_only else ("y_train", "subjects_train", "y_test", "subjects_test")
    if data_path.exists():
        audit.check(sha(data_path) == config["data_sha256"].get(data_path.name), "prepared_dataset_hash")
        # Only labels and subject identities are needed; no features or model are evaluated.
        with np.load(data_path, allow_pickle=False) as saved:
            data = {k: saved[k] for k in dataset_members}
    else:
        audit.check(False, "dataset_available_for_independent_metric_labels", str(data_path))
    if holdout is not None and data is not None and not search_only:
        indices = np.asarray(holdout["final_test_indices"], dtype=np.int64)
        prior, purged = set(holdout["prior_evaluated_indices"]), set(holdout["purged_indices"])
        expected = set(prior)
        for i in prior:
            for j in (i-1, i+1):
                if 0 <= j < len(data["subjects_test"]) and data["subjects_test"][i] == data["subjects_test"][j]:
                    expected.add(j)
        audit.check(purged == expected and not set(indices) & purged, "holdout_prior_neighbor_exclusion")
        audit.check(loader_arrays_sha(indices, data["subjects_test"][indices], data["y_test"][indices]) == holdout["final_split_sha256"],
                    "holdout_split_signature")
    paths = sorted((campaign/"attempts").glob("[0-9][0-9][0-9][0-9][0-9].json"))
    audit.check(len(paths) == status["completed_attempts"], "status_journal_count")
    audit.check(status["planned_attempts"] == len(plan), "status_plan_count")
    manifest_path = campaign/"checkpoints"/"manifest.json"
    if paths:
        manifest = read(manifest_path)
        checkpoint_path = campaign/"checkpoints"/manifest["latest"]
        checkpoint = read(checkpoint_path)
        audit.check(sha(checkpoint_path) == manifest["latest_sha256"], "latest_checkpoint_hash")
        audit.check(checkpoint["config_sha256"] == sha(campaign/"config.json"), "checkpoint_config_hash")
        audit.check(checkpoint["deadline_unix"] == manifest["deadline_unix"] == authorization["deadline_unix"], "checkpoint_deadline")
        audit.check(checkpoint["completed_attempts"] == manifest["completed_attempts"] == len(paths), "checkpoint_journal_count")
        expected_journal = {path.name: sha(path) for path in paths}
        audit.check(checkpoint["journal_sha256"] == expected_journal, "entire_journal_hashes")
        audit.check(checkpoint["last_result_sha256"] == sha(paths[-1]), "latest_result_hash")
        audit.check(checkpoint["journal_last_index"] == len(paths)-1, "journal_cursor")
        audit.check(checkpoint["next_spec"] == (plan[len(paths)] if len(paths) < len(plan) else None), "resume_next_spec")
        audit.check(read(campaign/"checkpoints"/"most_complete.json") == checkpoint, "most_complete_checkpoint")
    rows, failed, process_walls = [], [], []
    reconstructed_splits = {}
    previous_end = authorization["start_unix"]
    previous_monotonic_end = None
    clock_discrepancies = []
    clock_version = config.get("clock_receipt_version", 1)
    for i, path in enumerate(paths):
        row = read(path)
        name = path.name
        audit.check(path.name == f"{i:05d}.json" and row["spec"] == plan[i], "journal_matches_plan", name)
        start, end, wall = row["attempt_start_unix"], row["attempt_end_unix"], row["process_wall_s"]
        audit.check(np.isfinite([start, end, wall]).all() and wall >= 0,
                    "finite_attempt_clock_values", name)
        audit.check(start >= authorization["start_unix"], "attempt_after_authorization", name)
        audit.check(start < authorization["deadline_unix"], "attempt_starts_before_deadline", name)
        audit.check(end <= authorization["deadline_unix"]+.1, "attempt_ends_by_deadline", name)
        if clock_version >= 2:
            audit.check(row.get("clock_receipt_version") == 2, "clock_receipt_version", name)
            mono_start = row["attempt_start_monotonic_s"]
            mono_process_end = row["process_end_monotonic_s"]
            mono_end = row["attempt_end_monotonic_s"]
            audit.check(np.isfinite([mono_start, mono_process_end, mono_end]).all()
                        and mono_start <= mono_process_end <= mono_end, "monotonic_process_enclosure", name)
            audit.close(wall, mono_process_end-mono_start, "monotonic_process_duration", name, 0)
            audit.close(row["attempt_wall_monotonic_s"], mono_end-mono_start, "monotonic_attempt_duration", name, 0)
            audit.close(row["utc_elapsed_s"], end-start, "utc_receipt_difference", name, 0)
            audit.close(row["utc_minus_monotonic_s"], (end-start)-(mono_end-mono_start), "clock_difference_receipt", name, 0)
            if previous_monotonic_end is not None:
                audit.check(mono_start >= previous_monotonic_end, "monotonic_serial_attempts", name)
            previous_monotonic_end = mono_end
            if abs(row["utc_minus_monotonic_s"]) > .001:
                clock_discrepancies.append(dict(attempt=name, utc_minus_monotonic_s=row["utc_minus_monotonic_s"],
                    scope="UTC correction/clock disagreement retained; monotonic elapsed interval is primary"))
        else:
            # Preserve the original legacy diagnostic; do not retrofit a missing receipt.
            audit.check(end >= start and start >= previous_end, "legacy_utc_serial_attempts", name)
            audit.check(end-start+.001 >= wall, "wall_clock_encloses_process", name)
        previous_end = end
        process_walls.append(wall)
        if row["status"] != "SUCCESS":
            failed.append(dict(index=i, method=row["spec"]["method"], status=row["status"]))
            continue
        rows.append(row)
        try:
            audit.check(row["source_hashes"] == config["source_hashes"], "worker_source_matches_config", name)
            audit.check(row["seed"] == row["spec"]["seed"] and row["method"] == row["spec"]["method"], "worker_identity", name)
            audit.check(all(row["config"][k] == v for k, v in row["spec"]["config"].items()), "worker_config", name)
            for field in ("import_and_setup_s", "application_s", "application_wall_s", "worker_before_write_s"):
                audit.check(np.isfinite(row[field]) and 0 <= row[field] <= wall, "timing_stage_enclosed", name+"/"+field)
            audit.check(row["application_s"]+.001 >= row["application_wall_s"], "worker_encloses_application", name)
            if clock_version >= 2:
                worker_start, worker_end = row["worker_start_monotonic_s"], row["worker_end_monotonic_s"]
                app_start, app_end = row["application_start_monotonic_s"], row["application_end_monotonic_s"]
                audit.check(np.isfinite([worker_start, worker_end, app_start, app_end]).all()
                            and mono_start <= worker_start <= app_start <= app_end <= worker_end <= mono_process_end,
                            "monotonic_worker_application_enclosure", name)
                audit.close(row["worker_before_write_s"], worker_end-worker_start, "monotonic_worker_duration", name, 0)
                audit.close(row["application_s"], app_end-app_start, "monotonic_application_duration", name, 0)
            d, cfg = row["diagnostics"], row["config"]
            timing = d["timing"]
            audit.check(all(np.isfinite(value) and value >= 0 for value in d["timings"].values()), "nonnegative_stage_costs", name)
            audit.check(timing["load_split_preprocess_hash_s"]+timing["train_select_test_s"] <= row["application_wall_s"]+.001,
                        "application_encloses_stages", name)
            audit.check(sum(d["timings"].values()) <= timing["train_select_test_s"]+.001, "training_encloses_all_stage_costs", name)
            provenance, pre = d["provenance"], d["preprocessing"]
            audit.check(hashlib.sha256(json.dumps(pre, sort_keys=True, allow_nan=False).encode()).hexdigest() == d["preprocessing_sha256"], "preprocessing_metadata_hash", name)
            audit.check(provenance["final_holdout_manifest_sha256"] == holdout_pin, "holdout_pin_per_worker", name)
            audit.check(provenance["final_holdout_indices"] == holdout["final_test_indices"], "holdout_indices_per_worker", name)
            audit.check(pre["fit_scope"] == "selected_training_rows_only" and pre["representation"] == cfg["representation"],
                        "train_only_preprocessing_receipt", name)
            audit.check(pre["fit_train_indices_sha256"] == loader_arrays_sha(np.asarray(provenance["selected_indices"]["train"], dtype=np.int64)),
                        "transform_training_indices_hash", name)
            if cfg["representation"] == "lda_tiled":
                audit.check(pre["coordinate_schema"] == [f"lda:{j%5}" for j in range(cfg["n_qubits"])], "lda_five_axis_tiling", name)
                audit.check(pre["lda"]["solver"] == "eigen" and pre["lda"]["shrinkage"] == "auto" and pre["intrinsic_lda_dimensions"] == 5,
                            "regularized_lda_contract", name)
            if cfg["representation"] == "pca_original":
                audit.check(pre["angle_map"] == "2*atan(z)" and pre["effective_angle_scale"] == 2, "angle_representation_contract", name)
            else:
                audit.check(pre["angle_map"] == "pi/2 + angle_scale*atan(z)" and pre["effective_angle_scale"] == cfg["angle_scale"],
                            "angle_representation_contract", name)
            labels = None
            if data is not None:
                labels = data["y_train"][provenance["selected_indices"]["validation"]]
                split_key = (row["seed"], cfg["n_train"], cfg["n_validation"])
                if split_key not in reconstructed_splits:
                    reconstructed_splits[split_key] = independently_selected_rows(data, *split_key)
                split_rows, subject_pool = reconstructed_splits[split_key]
                audit.check(provenance["validation_subject_pool"] == subject_pool, "validation_subject_seed_parity", name)
                for split in ("train", "validation"):
                    index = np.asarray(provenance["selected_indices"][split], dtype=np.int64)
                    audit.check(index.tolist() == split_rows[split], "subset_sampling_seed_parity", name+"/"+split)
                    calculated = arrays_sha(index, data["subjects_train"][index], data["y_train"][index])
                    audit.check(calculated == d["split_sha256"][split], "diagnostic_split_identity_hash", name+"/"+split)
                    loader_calculated = loader_arrays_sha(index, data["subjects_train"][index], data["y_train"][index])
                    audit.check(loader_calculated == provenance["split_sha256"][split], "provenance_split_identity_hash", name+"/"+split)
                if pre.get("lda") is not None:
                    train_index = provenance["selected_indices"]["train"]
                    audit.check(pre["supervised_fit_labels_sha256"] == loader_arrays_sha(data["y_train"][train_index]), "lda_training_label_hash", name)
            selected_subjects = provenance["selected_subjects"]
            splits = ("train", "validation") if cfg["validation_only"] else ("train", "validation", "test")
            for ix, left in enumerate(splits):
                for right in splits[ix+1:]:
                    audit.check(not set(selected_subjects[left]) & set(selected_subjects[right]), "subject_disjointness", name)
            if not cfg["validation_only"]:
                audit.check(provenance["selected_indices"]["test"] == holdout["final_test_indices"], "final_holdout_only", name)
                audit.check(provenance["split_sha256"]["test"] == holdout["final_split_sha256"], "final_holdout_provenance_signature", name)
                if data is not None:
                    test_index = np.asarray(holdout["final_test_indices"], dtype=np.int64)
                    test_diagnostic_hash = arrays_sha(test_index, data["subjects_test"][test_index], data["y_test"][test_index])
                    audit.check(d["split_sha256"]["test"] == test_diagnostic_hash, "final_holdout_diagnostic_signature", name)
                if data is not None:
                    audit.check(d["test_labels"] == data["y_test"][holdout["final_test_indices"]].tolist(), "test_labels_from_frozen_rows", name)
                calculated = metrics(d["test_labels"], d["test_probabilities"])
                audit.metric(row["test_metrics"], calculated, name+"/test")
                audit.metric(d["test_metrics"], calculated, name+"/test_diagnostic")
                audit.check(d["test_predictions"] == np.asarray(d["test_probabilities"]).argmax(axis=1).tolist(), "test_predictions", name)
                audit.close(row["metric_value"], calculated["balanced_accuracy"], "primary_metric_value", name)
            if row["method"] in (*QML, "frozen_quantum"):
                audit.trajectory(row, labels)
            else:
                audit.classical(row, labels)
        except Exception as error:
            audit.errors.append(f"attempt_schema_or_audit: {name}: {type(error).__name__}: {error}")
    groups = defaultdict(list)
    for row in rows:
        spec = row["spec"]
        groups[(spec["condition"], spec["seed"], spec["repeat"])].append(row)
    matched = 0
    for key, group in groups.items():
        representative = group[0]
        for row in group[1:]:
            for field in ("dataset_sha256", "split_sha256", "feature_sha256", "preprocessing_sha256"):
                audit.check(row["diagnostics"][field] == representative["diagnostics"][field], "matched_data_identity", str(key)+"/"+field)
            audit.check(row["source_hashes"] == representative["source_hashes"], "matched_code_identity", str(key))
        qml = {row["method"]: row for row in group if row["method"] in QML}
        if set(qml) == set(QML):
            matched += 1
            anchor = qml["group_spectral"]
            for method in QML[1:]:
                other = qml[method]
                error = audit.close(other["validation_vector"], anchor["validation_vector"], "matched_complete_qml_trajectory", str(key)+"/"+method)
                audit.max_matching_error = max(audit.max_matching_error, error)
                audit.check(other["diagnostics"]["engine"]["source_sha256"] == anchor["diagnostics"]["engine"]["source_sha256"],
                            "matched_quantum_source_signature", str(key)+"/"+method)
    attempt_cost_audit = verify_attempt_costs(campaign, config, status, paths, audit)
    planned_counts, successful_counts = Counter(p["method"] for p in plan), Counter(r["method"] for r in rows)
    complete = len(paths) == len(plan) and len(rows) == len(plan) and status["status"] == "COMPLETE"
    audit.check(status.get("unattempted", len(plan)-len(paths)) == len(plan)-len(paths), "missing_coverage_preserved")
    if status["status"] == "COMPLETE":
        audit.check(len(paths) == len(plan), "complete_status_has_full_journal")
    return dict(status="FAIL" if audit.errors else "PASS" if complete else "PARTIAL",
                errors=audit.errors, planned_attempts=len(plan), attempted_attempts=len(paths),
                successful_attempts=len(rows), failed_attempts=failed, missing_attempts=len(plan)-len(paths),
                matched_qml_blocks=matched, max_matching_error=audit.max_matching_error if np.isfinite(audit.max_matching_error) else None,
                max_adam_replay_error=audit.max_adam_error if np.isfinite(audit.max_adam_error) else None, planned_method_counts=dict(planned_counts),
                successful_method_counts=dict(successful_counts), complete_successful_coverage=complete,
                process_wall_s=sum(process_walls), campaign_status=status,
                clock_receipt_version=clock_version, utc_monotonic_discrepancies=clock_discrepancies,
                attempt_costs=attempt_cost_audit,
                dataset_members_opened=list(dataset_members) if data is not None else [],
                test_partition_labels_read=bool(data is not None and not search_only),
                checks=dict(audit.checks), seconds=time.perf_counter()-started,
                source_contract_review="Static source statements and metadata checked against the reviewed pilot formula; no project module imported.",
                limitations="Saved-data replay verifies recorded gradients drive the recorded Adam updates; it does not recompute quantum gradients. The fixed holdout was selected with adjacent-row purge within previously used test subjects. Numerical-repair reruns reuse those already evaluated rows; they are not fresh or external validation.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--campaign", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--holdout", type=Path)
    args = parser.parse_args()
    started = time.perf_counter()
    try:
        result = audit_campaign(args.campaign.resolve(), args.repo.resolve(), args.data_dir, args.holdout)
    except Exception as error:
        result = dict(status="FAIL", errors=[f"Audit setup failed: {type(error).__name__}: {error}"],
                      planned_attempts=0, successful_attempts=0, matched_qml_blocks=0,
                      max_matching_error=None, checks={}, seconds=time.perf_counter()-started)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(args.output.suffix+".tmp")
    temporary.write_text(json.dumps(result, indent=2, allow_nan=False)+"\n")
    temporary.replace(args.output)
    print(json.dumps({key: result.get(key) for key in ("status", "planned_attempts", "successful_attempts", "matched_qml_blocks", "max_matching_error", "seconds", "errors")}))
    return 1 if result["status"] == "FAIL" else 0


if __name__ == "__main__":
    sys.exit(main())
