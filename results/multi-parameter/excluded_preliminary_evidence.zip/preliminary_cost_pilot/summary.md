# Scaling response memory: qubits and independent parameters

Fresh local CPU simulations. The old dense-block measurements are not pooled with these matrix-free architectures. No QPU or finite-shot claim.

12/12 successful attempts; 2/2 matched blocks. Maximum complete-trajectory error: 5.25e-15; unchanged absolute tolerance 1e-10.

Each process clock encloses imports, data, preparation, compilation, response construction and native checks, cache planning, all parameter updates, head fitting, prediction, serialization and exit. Parent orchestration, preflight, resume smoke and reporting are separate measured costs. Installation and development are excluded.

| Condition | Qubits | Independent angles | Occurrences each | Layers | State coefficients | Response grid points |
|---|---:|---:|---:|---:|---:|---:|
| sensor-n12-p4 | 12 | 4 | 2 | 8 | 81 | 625 |
| sensor-n14-p2 | 14 | 2 | 4 | 8 | 25 | 81 |

| Condition | Method | Full process (s) | Accuracy | Native Aer evaluations |
|---|---|---:|---:|---:|
| sensor-n12-p4 | GroupMemory spectral | 2.9709 | 100.00% | 8 |
| sensor-n12-p4 | GroupMemory batched grid | 19.8302 | 100.00% | 8 |
| sensor-n12-p4 | Qiskit runtime-bound response | 16.7378 | 100.00% | 2512 |
| sensor-n12-p4 | Qiskit batched occurrence shifts | 6.8203 | 100.00% | 824 |
| sensor-n12-p4 | Direct state and adjoint | 2.4416 | 100.00% | 0 |
| sensor-n12-p4 | Classical task model | 1.5081 | 100.00% | 0 |
| sensor-n14-p2 | GroupMemory spectral | 4.5595 | 100.00% | 8 |
| sensor-n14-p2 | GroupMemory batched grid | 15.1131 | 100.00% | 8 |
| sensor-n14-p2 | Qiskit runtime-bound response | 11.5476 | 100.00% | 336 |
| sensor-n14-p2 | Qiskit batched occurrence shifts | 22.1298 | 100.00% | 824 |
| sensor-n14-p2 | Direct state and adjoint | 4.2088 | 100.00% | 0 |
| sensor-n14-p2 | Classical task model | 1.9571 | 100.00% | 0 |

## Matched comparisons

Ratios use paired seed medians, not marginal median times. A descriptive win requires five complete paired seeds, three matched repeats each, every seed median faster and at least 5% median paired saving. Ranges are observed seeds, not confidence intervals. Missing/failed attempts never count as fast results.

| Condition | Baseline | Spectral speedup | Seed range | Meets rule |
|---|---|---:|---:|---|
| sensor-n12-p4 | GroupMemory batched grid | 6.675× | 6.675–6.675× | False |
| sensor-n12-p4 | Qiskit runtime-bound response | 5.634× | 5.634–5.634× | False |
| sensor-n12-p4 | Qiskit batched occurrence shifts | 2.296× | 2.296–2.296× | False |
| sensor-n12-p4 | Direct state and adjoint | 0.822× | 0.822–0.822× | False |
| sensor-n12-p4 | Classical task model | 0.508× | 0.508–0.508× | False |
| sensor-n14-p2 | GroupMemory batched grid | 3.315× | 3.315–3.315× | False |
| sensor-n14-p2 | Qiskit runtime-bound response | 2.533× | 2.533–2.533× | False |
| sensor-n14-p2 | Qiskit batched occurrence shifts | 4.854× | 4.854–4.854× | False |
| sensor-n14-p2 | Direct state and adjoint | 0.923× | 0.923–0.923× | False |
| sensor-n14-p2 | Classical task model | 0.429× | 0.429–0.429× | False |

## Faster of the Qiskit controls

The faster Qiskit seed median is selected separately for each seed. This deliberately favors Qiskit and is not a deployed adaptive selector.

| Condition | Paired speedup | Time saving | Meets rule |
|---|---:|---:|---|
| sensor-n12-p4 | 2.296× | 56.44% | False |
| sensor-n14-p2 | 2.533× | 60.52% | False |

## Scope and limitations

The independent angles really are updated separately. Their repeated gate occurrences are interleaved with fixed noncommuting rotations and ring entanglers. The response is a full multidimensional Fourier tensor, including mixed-sign frequencies. All response methods receive the same support, exact input identities, cache lifetime and native off-grid checks. Spatial input equivalence is not assumed.

The additional Qiskit control batches occurrence-local parameter shifts and sums them per independent parameter, using native runtime binding and exact job reuse. It avoids full response reconstruction and supplies a stronger alternative when the response table grows expensive.

Local-gate propagation removes the old dense 4^n block operators, but state storage still grows as 2^n. With p angles repeated r times each, the state coefficient count is (r+1)^p and response grid is (2r+1)^p. Chunking bounds temporary arrays; it does not remove exponential work. Library/import memory is additional to the algorithm's guarded array budget.

The batched-grid ablation tests ordinary batching. The direct adjoint control computes the identical model and all angle derivatives without persistent response reconstruction. The task-specific classical classifier uses different features and is compared on both accuracy and time. Sensor views share underlying base patterns; data seeds do not vary the architecture.

Classical coefficient propagation and native Aer calls are different costs. Fewer native calls do not establish physical CNOT, shot or hardware savings.

Worker process walls sum to 109.825 s; last parent measurement invocation: 109.865 s.
