"""Bounded train/validation-only representation and training-length exploration.

This development script opens only the three official training-partition NPZ
members. It does not read or evaluate the test partition. Timings describe a
shared-process exploratory search, never a final method benchmark.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys
from time import perf_counter

import numpy as np
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parent.parent/'group-memory-qml'/'src'))
from group_memory_qml.real_sensor_data import _balanced_subset
from group_memory_qml.real_sensor_model import PatchResponseModel
from group_memory_qml.real_sensor_training import _softmax, _metrics, _loss_gradients, _pack, _unpack


def write(path, payload):
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(payload,indent=2,allow_nan=False)+'\n')
    temporary.replace(path)


def split_train_validation(raw, seed):
    subjects=raw['subjects_train']; labels=raw['y_train']
    rng=np.random.default_rng(np.random.SeedSequence([seed,1001]))
    validation_subjects=np.sort(rng.permutation(np.unique(subjects))[:5])
    validation_pool=np.flatnonzero(np.isin(subjects,validation_subjects))
    train_pool=np.flatnonzero(~np.isin(subjects,validation_subjects))
    train=_balanced_subset(labels,subjects,train_pool,512,np.random.SeedSequence([seed,2001]))
    validation=_balanced_subset(labels,subjects,validation_pool,128,np.random.SeedSequence([seed,2002]))
    assert not set(subjects[train])&set(subjects[validation])
    scaler=StandardScaler().fit(raw['X_train'][train])
    return (scaler.transform(raw['X_train'][train]),scaler.transform(raw['X_train'][validation]),
            labels[train],labels[validation],dict(train_indices=train.tolist(),validation_indices=validation.tolist(),
            train_subjects=sorted(np.unique(subjects[train]).tolist()),
            validation_subjects=sorted(np.unique(subjects[validation]).tolist())))


def representations(train, validation, labels, seed):
    tick=perf_counter()
    pca=PCA(n_components=16,svd_solver='randomized',random_state=seed,iterated_power=4).fit(train)
    pca_train,pca_validation=pca.transform(train),pca.transform(validation)
    pca_time=perf_counter()-tick
    tick=perf_counter()
    lda=LinearDiscriminantAnalysis(n_components=5,solver='eigen',shrinkage='auto').fit(train,labels)
    lda_train,lda_validation=lda.transform(train),lda.transform(validation)
    lda_time=perf_counter()-tick
    def standardized(a,b):
        scaler=StandardScaler().fit(a)
        return scaler.transform(a),scaler.transform(b)
    pcat,pcav=standardized(pca_train,pca_validation)
    ldat,ldav=standardized(lda_train,lda_validation)
    indices=np.arange(16)%5
    hybridt=np.c_[ldat,pcat[:,:11]]; hybridv=np.c_[ldav,pcav[:,:11]]
    return {
        'pca_original':(2*np.arctan(pcat),2*np.arctan(pcav)),
        'pca_shifted':(np.pi/2+.5*np.arctan(pcat),np.pi/2+.5*np.arctan(pcav)),
        'lda_tiled':(np.pi/2+.5*np.arctan(ldat[:,indices]),np.pi/2+.5*np.arctan(ldav[:,indices])),
        'lda_pca':(np.pi/2+.5*np.arctan(hybridt),np.pi/2+.5*np.arctan(hybridv)),
    },dict(pca_fit_transform_s=pca_time,lda_fit_transform_s=lda_time,
        lda_axes=5,lda_tiled_indices=indices.tolist(),fit_scope='selected_training_rows_only',
        shifted_map='pi/2 + 0.5*atan(StandardScaler(projected))'),(ldat,ldav)


def train_qml(X,V,y,yv,seed,deadline,freeze=False):
    started=perf_counter(); model=PatchResponseModel(16,'group_spectral')
    rng=np.random.default_rng(np.random.SeedSequence([seed,61527]))
    theta=rng.uniform(-.7,.7,16); weights=rng.normal(0,.1,(8,6)); bias=np.zeros(6)
    parameters=_pack(theta,weights,bias); initial=parameters.copy()
    m=np.zeros_like(parameters); v=np.zeros_like(parameters)
    tick=perf_counter()
    # Fixed-head ablation does not construct an unnecessary parameter response.
    train_fixed,_=model.evaluate(X,theta,gradient=False) if freeze else (None,None)
    validation_features,_=model.evaluate(V,theta,gradient=not freeze)
    validation_fixed=validation_features.copy() if freeze else None
    probabilities,_=_softmax(validation_features@weights+bias)
    best=_metrics(yv,probabilities); best_step=0; best_parameters=parameters.copy()
    calibration_s=perf_counter()-tick
    checkpoints={}; final_step=0
    for step in range(1,1001):
        if perf_counter()>=deadline:break
        theta,weights,bias=_unpack(parameters,16)
        if freeze:
            features=train_fixed;jacobian=np.zeros((len(X),8,2))
        else:
            features,jacobian=model.evaluate(X,theta,gradient=True)
        loss,probabilities,gt,gw,gb=_loss_gradients(features,jacobian,y,weights,bias,1e-4)
        gradient=_pack(gt,gw,gb)
        m=.9*m+.1*gradient;v=.999*v+.001*gradient*gradient
        parameters-=.03*(m/(1-.9**step))/(np.sqrt(v/(1-.999**step))+1e-8)
        theta,weights,bias=_unpack(parameters,16)
        features=validation_fixed if freeze else model.evaluate(V,theta,gradient=False)[0]
        validation=_metrics(yv,_softmax(features@weights+bias)[0])
        if validation['log_loss']<best['log_loss']:
            best=validation;best_step=step;best_parameters=parameters.copy()
        final_step=step
        if step in (60,300,1000):
            checkpoints[str(step)]={'best_validation':best,'best_step':best_step,
                                   'current_validation':validation,'training_regularized_log_loss':loss,
                                   'training_accuracy':float(np.mean(probabilities.argmax(1)==y))}
    return dict(steps_finished=final_step,best_validation=best,best_step=best_step,
        checkpoints=checkpoints,search_run_s=perf_counter()-started,initial_calibration_s=calibration_s,
        independent_angles=16,trainable_angles=0 if freeze else 16,
        angle_displacement_norm=float(np.linalg.norm(best_parameters[:16]-initial[:16])),
        max_correctness_error=model.diagnostics['max_check_error'],
        compute='Ideal CPU simulation; exploratory shared-process timing only',
        frozen_quantum=freeze)


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--data-dir',type=Path,required=True)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'))
    parser.add_argument('--budget-seconds',type=float,default=285.)
    args=parser.parse_args();started=perf_counter();deadline=started+args.budget_seconds
    members=('X_train','y_train','subjects_train')
    path=args.data_dir/'har_features.npz'
    with np.load(path,allow_pickle=False) as saved:raw={key:saved[key] for key in members}
    payload=dict(status='RUNNING',budget_s=args.budget_seconds,seeds=[966001,966002],
        npz_members_opened=list(members),test_partition_read=False,test_predictions_evaluated=False,
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        candidates=['pca_original','pca_shifted','lda_tiled','lda_pca'],
        results=[],representations={},classical_lda_controls=[],
        scope='Exploratory training/validation search; not fresh-process final benchmark')
    for seed in payload['seeds']:
        if perf_counter()>=deadline:break
        tick=perf_counter();X,V,y,yv,split=split_train_validation(raw,seed)
        reps,metadata,lda_arrays=representations(X,V,y,seed)
        payload['representations'][str(seed)]={**metadata,**split,'preparation_s':perf_counter()-tick}
        tick=perf_counter();clf=LogisticRegression(C=1,solver='lbfgs',max_iter=1000,tol=1e-8)
        clf.fit(lda_arrays[0],y)
        payload['classical_lda_controls'].append(dict(seed=seed,method='logistic_on_five_LDA_axes',
            validation=_metrics(yv,clf.predict_proba(lda_arrays[1])),fit_predict_s=perf_counter()-tick))
        for name,(train,validation) in reps.items():
            if perf_counter()>=deadline:break
            result=train_qml(train,validation,y,yv,seed,deadline)
            payload['results'].append(dict(seed=seed,representation=name,**result))
            print(json.dumps({k:payload['results'][-1][k] for k in ('seed','representation','best_validation','best_step','search_run_s')}),flush=True)
            write(args.output,payload)
            if perf_counter()<deadline:
                result=train_qml(train,validation,y,yv,seed,deadline,freeze=True)
                payload['results'].append(dict(seed=seed,representation=name,**result))
                write(args.output,payload)
    payload['elapsed_s']=perf_counter()-started
    payload['status']='COMPLETE' if len(payload['results'])==16 and all(x['steps_finished']==1000 for x in payload['results']) else 'BUDGET_EXHAUSTED'
    payload['negative_results_preserved']=True
    write(args.output,payload)
    print(json.dumps({'status':payload['status'],'runs':len(payload['results']),'elapsed_s':payload['elapsed_s']}))


if __name__=='__main__':main()
