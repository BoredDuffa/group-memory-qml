"""Time one bounded local phase and retain all output; no remote resources."""
from pathlib import Path
import subprocess,sys,os,time,json,signal
base=Path(__file__).resolve().parent.parent
repo=base/'group-memory-qml'; out=base/'outputs/Improved_sensor_benchmark'
out.mkdir(exist_ok=True,parents=True)
phase=sys.argv[1]
env=os.environ.copy();env.update(PYTHONPATH=str(repo/'src'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMEXPR_NUM_THREADS='1',RAYON_NUM_THREADS='1',PYTHONHASHSEED='0')
python=str(base/'work/.venv/bin/python')
if phase=='preflight': cmd=[python,'-m','pytest','-q']; timeout=300
else:
 name,condition,seeds,repeats,budget=({'quick':('quick','improved_sensor_quick.json',['956001'],1,600),'pilot':('pilot','improved_sensor_pilot.json',['956011'],1,600),'main':('campaign','improved_sensor.json',['956101','956102','956103','956104','956105'],2,1800)})[phase]
 cmd=[python,'-m','group_memory_qml.improved_sensor_suite','run','--conditions',str(repo/'benchmarks'/condition),'--data-dir',str(base/'work/data/uci_har'),'--output',str(out/name),'--seeds',*seeds,'--repeats',str(repeats),'--budget-seconds',str(budget)]
 if len(sys.argv)>2:cmd+=['--limit',sys.argv[2]]
 timeout=budget+30
suffix='_'+sys.argv[2] if len(sys.argv)>2 else ''
started=time.perf_counter();start_unix=time.time()
with (out/f'{phase}{suffix}.log').open('w') as log:
 process=subprocess.Popen(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=process.wait(timeout=timeout)
 except subprocess.TimeoutExpired:
  os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
  code=124
receipt={'phase':phase,'seconds':time.perf_counter()-started,'start_unix':start_unix,'end_unix':time.time(),'returncode':code,'scope':'Local CPU only; includes parent startup and complete child lifecycle','log':f'{phase}{suffix}.log'}
(out/f'{phase}{suffix}_wall.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
sys.exit(code)
