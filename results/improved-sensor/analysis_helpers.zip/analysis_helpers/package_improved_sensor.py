"""Package only terminal, independently audited improved-sensor evidence.

No experiment is executed. Raw attempt bytes and frozen Git source bytes are
preserved and individually hashed. The --refresh-manifest mode adds rendered
report outputs and rebuilds the final public manifest after report execution.
No Git commit, push, raw dataset copy or remote operation occurs here.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from time import perf_counter
import zipfile

WORK=Path(__file__).resolve().parent
BASE=WORK.parent
REPO=BASE/'group-memory-qml'
DEFAULT_OUTPUT=BASE/'outputs'/'Improved_sensor_stable'
DEFAULT_PUBLIC=REPO/'results'/'improved-sensor'


def read(path):return json.loads(path.read_text())
def digest(raw):return hashlib.sha256(raw).hexdigest()
def sha(path):return digest(path.read_bytes())
def write(path,payload):path.write_text(json.dumps(payload,indent=2,allow_nan=False)+'\n')


def scan_bytes(raw,label):
    """High-confidence credential/private-home-path checks, not a security proof."""
    text=raw.decode('utf-8',errors='ignore')
    patterns={
        'private_key':r'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
        'github_token':r'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b',
        'openai_project_token':r'\bsk-proj-[A-Za-z0-9_-]{30,}',
        'aws_access_key':r'\bAKIA[0-9A-Z]{16}\b',
        'absolute_user_home':r'/(?:Users|home)/[A-Za-z0-9._-]+/',
    }
    findings=[kind for kind,pattern in patterns.items() if re.search(pattern,text)]
    if findings:raise ValueError(f'Public content scan rejected {label}: {", ".join(findings)}')


def scan_public(directory):
    checked=archive_members=0
    banned_suffixes={'.npz','.npy','.parquet','.h5','.hdf5','.pt','.pth','.safetensors'}
    for path in sorted(directory.rglob('*')):
        if not path.is_file():continue
        relative=path.relative_to(directory).as_posix()
        if path.suffix.lower() in banned_suffixes:
            raise ValueError(f'Raw dataset/model binary is outside this package: {relative}')
        if path.suffix.lower()=='.zip':
            with zipfile.ZipFile(path) as archive:
                for member in archive.infolist():
                    if member.is_dir():continue
                    parts=Path(member.filename).parts
                    if Path(member.filename).is_absolute() or '..' in parts:
                        raise ValueError(f'Unsafe archive member: {relative}/{member.filename}')
                    if Path(member.filename).suffix.lower() in banned_suffixes:
                        raise ValueError(f'Raw dataset/model binary in archive: {relative}/{member.filename}')
                    scan_bytes(archive.read(member),relative+'/'+member.filename)
                    archive_members+=1
        elif path.suffix.lower() not in ('.png','.jpg','.jpeg','.pdf'):
            scan_bytes(path.read_bytes(),relative)
        checked+=1
    return dict(status='PASS',files_scanned=checked,archive_members_scanned=archive_members,
        checks=['Private-key blocks','Recognizable GitHub/OpenAI/AWS credential patterns',
                'Absolute user-home paths','Unexpected raw dataset/model binaries','Safe ZIP member paths'],
        limitation='Pattern scan and explicit file allowlist; not a proof that every possible secret is absent')


def deterministic_zip(destination,entries,internal_manifest=False):
    hashes={}
    original_names=set(entries)
    if internal_manifest:
        entries=dict(entries)
        entries['SHA256SUMS']=''.join(digest(raw)+'  '+name+'\n' for name,raw in sorted(entries.items())).encode()
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,raw in sorted(entries.items()):
            scan_bytes(raw,name)
            info=zipfile.ZipInfo(name,date_time=(2026,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o644<<16
            archive.writestr(info,raw)
            hashes[name]=digest(raw)
    # Read back decompressed members and verify exact preservation.
    with zipfile.ZipFile(destination) as archive:
        if set(archive.namelist())!=set(hashes):raise ValueError('Archive member mismatch')
        for name,expected in hashes.items():
            if digest(archive.read(name))!=expected:raise ValueError('Archive byte mismatch')
    return {name:value for name,value in hashes.items() if name in original_names}


def terminal_checks(output):
    campaign=output/'campaign'
    status=read(campaign/'status.json');audit=read(output/'audit.json')
    if status.get('status')!='COMPLETE':
        raise ValueError('Only a terminal COMPLETE campaign may be packaged by this script')
    if (audit.get('status')!='PASS' or audit.get('errors')!=[]
            or audit.get('complete_successful_coverage') is not True
            or not isinstance(audit.get('max_matching_error'),(int,float))
            or not 0 <= audit['max_matching_error'] <= 1e-10):
        raise ValueError('Independent final audit must PASS without errors')
    config=read(campaign/'config.json');planned=len(config['plan'])
    if (status['completed_attempts']!=planned or status['planned_attempts']!=planned or
            audit['planned_attempts']!=planned or audit['successful_attempts']!=planned):
        raise ValueError('Complete successful coverage has not been established')
    paths=sorted((campaign/'attempts').glob('*.json'))
    if [p.name for p in paths]!=[f'{i:05d}.json' for i in range(planned)]:
        raise ValueError('Raw attempt journal is incomplete or contains unexpected files')
    for i,path in enumerate(paths):
        row=read(path)
        if row['status']!='SUCCESS' or row['spec']!=config['plan'][i]:
            raise ValueError('Raw attempt status/spec does not match the frozen plan')
        if row['source_hashes']!=config['source_hashes']:
            raise ValueError('Raw attempt source differs from the frozen campaign')
    revision=read(output/'code_revision.json')
    commit=revision.get('commit',revision.get('revision'))
    if not isinstance(commit,str) or not re.fullmatch('[0-9a-f]{40}',commit):
        raise ValueError('A complete frozen Git commit identifier is required')
    subprocess.run(['git','cat-file','-e',commit+'^{commit}'],cwd=REPO,check=True,capture_output=True)
    return campaign,status,audit,config,paths,commit


def frozen_source(commit,config):
    tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=REPO,text=True).splitlines()
    names=[name for name in tracked if name.startswith(('src/','tests/','benchmarks/','docs/','.github/'))
           or name in ('pyproject.toml','LICENSE','README.md','.gitignore')]
    entries={name:subprocess.check_output(['git','show',f'{commit}:{name}'],cwd=REPO) for name in names}
    for name,expected in config['source_hashes'].items():
        path='src/group_memory_qml/'+name
        if path not in entries or digest(entries[path])!=expected:
            raise ValueError(f'Frozen Git source does not match campaign hash: {path}')
    return entries


def helper_sources():
    names=('sensor_improved_design.py','audit_improved_sensor.py','summarize_improved_sensor.py',
           'run_improved_sensor_phase.py','build_improved_sensor_report.py','package_improved_sensor.py',
           'stable_sensor_pilot.py','stable_sensor_confirmation.py','stable_sensor_lower_lr.py',
           'package_rejected_sensor.py')
    result={}
    for name in names:
        path=WORK/name
        if not path.exists():raise FileNotFoundError(f'Required reproducibility helper missing: {name}')
        result['analysis_helpers/'+name]=path.read_bytes()
    search=read(WORK/'sensor_improved_design.json')
    if digest(result['analysis_helpers/sensor_improved_design.py'])!=search['source_sha256']:
        raise ValueError('Recorded development search source has changed')
    return result


def copy_report(output,public):
    for name in ('Improved_sensor_benchmark.html','main_runtime_accuracy.png','quality_ablations.png',
                 'main_learning_curves.png','frozen_angle_comparison.png','report_build_receipt.json'):
        path=output/name
        if path.exists():shutil.copy2(path,public/name)
    notebook=output/'Improved_sensor_benchmark.ipynb'
    if notebook.exists():
        raw=read(notebook)
        code=[cell for cell in raw['cells'] if cell['cell_type']=='code']
        if not code or any(cell.get('execution_count') is None for cell in code):
            raise ValueError('Refusing to publish an unexecuted report notebook')
        if any(out.get('output_type')=='error' for cell in code for out in cell.get('outputs',[])):
            raise ValueError('Refusing to publish a report notebook with execution errors')
        shutil.copy2(notebook,REPO/'examples'/'improved_sensor_benchmark.ipynb')
        write(public/'report_notebook_identity.json',dict(
            repository_path='examples/improved_sensor_benchmark.ipynb',sha256=sha(notebook),
            executed_code_cells=len(code)))


def manifest(public):
    findings=scan_public(public)
    write(public/'public_content_scan.json',findings)
    lines=[]
    for path in sorted(public.rglob('*')):
        if path.is_file() and path.name!='SHA256SUMS':
            lines.append(sha(path)+'  '+path.relative_to(public).as_posix())
    (public/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
    return len(lines),findings


def package(output,public):
    started=perf_counter();campaign,status,audit,config,attempts,commit=terminal_checks(output)
    required=('audit.json','summary.csv','comparisons.csv','seed_medians.csv','timing_accounting.json',
              'code_revision.json','final_holdout_manifest.json','preflight.log','preflight_wall.json',
              'summary_all_overhead.csv','comparisons_all_overhead.csv','seed_medians_all_overhead.csv',
              'rejected_package_receipt.json','numerical_repair.json','selection_freeze.json','study_cost_ledger.json',
              'pilot_audit.json','stable_sensor_search_summary.json')
    for name in required:
        if not (output/name).exists():raise FileNotFoundError(f'Required evidence missing: {name}')
    if public.exists() and (public/'config.json').exists():
        if sha(public/'config.json')!=sha(campaign/'config.json'):
            raise ValueError('Refusing to overwrite a public package from another campaign')
    public.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.improved-sensor-stage-',dir=public.parent) as temporary:
        stage=Path(temporary)
        for name in ('config.json','authorization.json','environment.json','status.json'):
            shutil.copy2(campaign/name,stage/name)
        shutil.copytree(campaign/'checkpoints',stage/'checkpoints')
        shutil.copytree(campaign/'attempt_costs',stage/'attempt_costs')
        for path in sorted(campaign.glob('*cost*.json')):
            shutil.copy2(path,stage/path.name)
        rejected=read(output/'rejected_package_receipt.json')
        expected={item['file']:item for item in rejected['archives']}
        if {p.name for p in output.glob('rejected*.zip')}!=set(expected):raise ValueError('Rejected archive inventory differs from its receipt')
        for name,item in expected.items():
            path=output/name
            if path.stat().st_size >= 50*1024*1024:raise ValueError('Rejected archive exceeds public size target')
            if path.stat().st_size!=item['bytes'] or sha(path)!=item['sha256']:raise ValueError('Rejected archive byte identity differs')
            shutil.copy2(path,stage/path.name)
        # Root-level JSON/CSV/log receipts preserve initial failures and repaired audit metadata.
        for path in sorted(output.iterdir()):
            if path.is_file() and path.suffix in ('.json','.csv','.log','.md'):
                shutil.copy2(path,stage/path.name)
        for name in ('prepared_manifest.json','download_receipt.json'):
            shutil.copy2(WORK/'data'/'uci_har'/name,stage/name)
        for name in ('sensor_improved_design.json','sensor_improved_design.log','improved_sensor_protocol_draft.md'):
            shutil.copy2(WORK/name,stage/name)
        rawhashes={};raw_shards=[]
        for offset in range(0,len(attempts),25):
            chunk=attempts[offset:offset+25]
            name=f'raw_attempts_{offset:05d}_{offset+len(chunk)-1:05d}.zip'
            hashes=deterministic_zip(stage/name,{p.name:p.read_bytes() for p in chunk},internal_manifest=True)
            if (stage/name).stat().st_size >= 50*1024*1024:raise ValueError('Raw attempt shard exceeds the public size bound')
            rawhashes.update(hashes)
            raw_shards.append(dict(archive=name,sha256=sha(stage/name),bytes=(stage/name).stat().st_size,members=hashes))
        write(stage/'raw_attempt_sha256.json',rawhashes)
        write(stage/'raw_attempt_shards.json',dict(shards=raw_shards,raw_attempts=len(rawhashes),byte_preserved=True))
        # Derived numerical traces remain local; publish their exact receipt hashes and reproduce script.
        stability_trace_index={}
        for stem in ('stable_sensor_pilot','stable_sensor_confirmation','stable_sensor_lower_lr'):
            for suffix in ('.json','.log'):
                path=WORK/(stem+suffix)
                if path.exists():shutil.copy2(path,stage/path.name)
            path=WORK/(stem+'.json')
            if path.exists():
                receipt=read(path)
                script=WORK/(stem+'.py')
                if sha(script)!=receipt['source_script_sha256']:raise ValueError('Executed stability pilot source changed')
                for record in receipt.get('records',[]):
                    artifact=record.get('trace_artifact')
                    if artifact:
                        local=BASE/artifact['path']
                        if sha(local)!=artifact['sha256']:raise ValueError('Local derived stability trace changed')
                        stability_trace_index[Path(artifact['path']).name]={key:artifact[key] for key in ('sha256','bytes')}
        write(stage/'stability_trace_index.json',dict(artifacts=stability_trace_index,
            bundled=False,scope='Local derived gradients, parameters and validation probabilities only; no sensor input arrays or labels. Raw arrays are not redistributed. Public JSON ledgers retain errors and exact hashes; scripts reproduce them.'))
        source=frozen_source(commit,config)
        write(stage/'source_snapshot_sha256.json',deterministic_zip(stage/'source_snapshot.zip',source))
        helpers=helper_sources()
        write(stage/'analysis_helpers_sha256.json',deterministic_zip(stage/'analysis_helpers.zip',helpers))
        pilot_entries={}
        for folder in ('quick','pilot'):
            directory=output/folder
            if not directory.exists():
                if folder=='pilot':raise FileNotFoundError('Required stable production pilot missing')
                continue
            for path in sorted(directory.rglob('*')):
                if path.is_file():pilot_entries[path.relative_to(output).as_posix()]=path.read_bytes()
        for path in sorted(output.iterdir()):
            if path.is_file() and (path.suffix=='.log' or
                    any(word in path.name for word in ('preflight','quick','pilot','resume','repair','initial_hash'))):
                pilot_entries[path.name]=path.read_bytes()
        write(stage/'preflight_and_pilots_sha256.json',
              deterministic_zip(stage/'preflight_and_pilots.zip',pilot_entries))
        packages=read(campaign/'environment.json')['packages']
        (stage/'requirements-measured.txt').write_text('\n'.join(f'{name}=={version}' for name,version in sorted(packages.items()))+'\n')
        (stage/'README.md').write_text(
            '# Improved real-sensor evidence\n\n'
            'This folder contains the terminal complete improved-sensor campaign and its independent audit. '
            'Raw attempt shards preserve exact JSON bytes; their manifest and companion hash map identify every member. '
            'The source archive comes from the frozen Git revision recorded in code_revision.json. '
            'Local analysis helpers, development search, numerical-stability search, preflight and pilot receipts remain separately available. '
            'The original completed 100-attempt run failed its strict trajectory audit and is preserved in explicitly rejected archives with its frozen source; it is excluded from all accepted performance claims.\n\n'
            'The executed report lives in examples/improved_sensor_benchmark.ipynb; its portable HTML and '
            'plot exports are added after rendering. SHA256SUMS covers the final files after that step. '
            'No raw feature arrays, model weights, credentials or machine-specific home paths are intentionally included.\n\n'
            'These are ideal CPU results for eight independent two-qubit patches. Supervised LDA is a '
            'classical part of the learning recipe. The fixed held-out rows come from the same nine official '
            'test subjects used previously. The numerical repair retests the same already evaluated holdout, not an independent external cohort.\n')
        write(stage/'package_receipt.json',dict(status='PACKAGED',frozen_commit=commit,
            planned_attempts=len(attempts),raw_attempts=len(rawhashes),raw_shards=len(raw_shards),frozen_source_files=len(source),
            preflight_pilot_members=len(pilot_entries),helper_files=len(helpers),
            package_seconds=perf_counter()-started,
            phase_scope='Archive/copy work through receipt creation; later rendering/manifest work is separate',
            raw_attempts_byte_preserved=True,source_from_frozen_git=True,raw_dataset_included=False))
        scan_public(stage)
        shutil.copytree(stage,public,dirs_exist_ok=True)
    copy_report(output,public)
    count,scan=manifest(public)
    return dict(status='PACKAGED',public_files=count,raw_attempts=len(attempts),
                frozen_commit=commit,content_scan=scan['status'],seconds=perf_counter()-started)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=DEFAULT_OUTPUT)
    parser.add_argument('--publicdir',type=Path,default=DEFAULT_PUBLIC)
    parser.add_argument('--refresh-manifest',action='store_true')
    args=parser.parse_args();output=args.output.resolve();public=args.publicdir.resolve()
    if args.refresh_manifest:
        started=perf_counter();terminal_checks(output)
        if not (public/'package_receipt.json').exists():raise ValueError('Create the initial package first')
        copy_report(output,public)
        for name in ('timing_accounting.json','audit.json','summary.csv','comparisons.csv','seed_medians.csv',
                     'summary_all_overhead.csv','comparisons_all_overhead.csv','seed_medians_all_overhead.csv',
                     'study_cost_ledger.json'):
            shutil.copy2(output/name,public/name)
        count,scan=manifest(public)
        result=dict(status='MANIFEST_REFRESHED',public_files=count,content_scan=scan['status'],seconds=perf_counter()-started)
    else:result=package(output,public)
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
