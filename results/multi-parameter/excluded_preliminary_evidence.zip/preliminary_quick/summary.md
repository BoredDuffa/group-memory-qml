# Scaling response memory: qubits and independent parameters

Fresh local CPU simulations. The old dense-block measurements are not pooled with these matrix-free architectures. No QPU or finite-shot claim.

12/12 successful attempts; 2/2 matched blocks. Maximum complete-trajectory error: 1.27e-14; unchanged absolute tolerance 1e-10.

Each process clock encloses imports, data, preparation, compilation, response construction and native checks, cache planning, all parameter updates, head fitting, prediction, serialization and exit. Parent orchestration, preflight, resume smoke and reporting are separate measured costs. Installation and development are excluded.

| Condition | Qubits | Independent angles | Occurrences each | Layers | State coefficients | Response grid points |
|---|---:|---:|---:|---:|---:|---:|
| sensor-smoke | 6 | 2 | 2 | 4 | 9 | 25 |
| shared-smoke | 6 | 2 | 2 | 4 | 9 | 25 |

| Condition | Method | Full process (s) | Accuracy | Native Aer evaluations |
|---|---|---:|---:|---:|
| sensor-smoke | GroupMemory spectral | 1.7065 | 100.00% | 8 |
| sensor-smoke | GroupMemory batched grid | 1.6596 | 100.00% | 8 |
| sensor-smoke | Qiskit runtime-bound response | 1.6053 | 100.00% | 112 |
| sensor-smoke | Qiskit batched occurrence shifts | 3.4595 | 100.00% | 80 |
| sensor-smoke | Direct state and adjoint | 1.6703 | 100.00% | 0 |
| sensor-smoke | Classical task model | 1.2855 | 100.00% | 0 |
| shared-smoke | GroupMemory spectral | 3.5676 | 100.00% | 8 |
| shared-smoke | GroupMemory batched grid | 1.5528 | 100.00% | 8 |
| shared-smoke | Qiskit runtime-bound response | 1.5428 | 100.00% | 112 |
| shared-smoke | Qiskit batched occurrence shifts | 2.3447 | 100.00% | 80 |
| shared-smoke | Direct state and adjoint | 1.3106 | 100.00% | 0 |
| shared-smoke | Classical task model | 1.4431 | 100.00% | 0 |

## Matched comparisons

Ratios use paired seed medians, not marginal median times. A descriptive win requires five complete paired seeds, three matched repeats each, every seed median faster and at least 5% median paired saving. Ranges are observed seeds, not confidence intervals. Missing/failed attempts never count as fast results.

| Condition | Baseline | Spectral speedup | Seed range | Meets rule |
|---|---|---:|---:|---|
| sensor-smoke | GroupMemory batched grid | 0.973× | 0.973–0.973× | False |
| sensor-smoke | Qiskit runtime-bound response | 0.941× | 0.941–0.941× | False |
| sensor-smoke | Qiskit batched occurrence shifts | 2.027× | 2.027–2.027× | False |
| sensor-smoke | Direct state and adjoint | 0.979× | 0.979–0.979× | False |
| sensor-smoke | Classical task model | 0.753× | 0.753–0.753× | False |
| shared-smoke | GroupMemory batched grid | 0.435× | 0.435–0.435× | False |
| shared-smoke | Qiskit runtime-bound response | 0.432× | 0.432–0.432× | False |
| shared-smoke | Qiskit batched occurrence shifts | 0.657× | 0.657–0.657× | False |
| shared-smoke | Direct state and adjoint | 0.367× | 0.367–0.367× | False |
| shared-smoke | Classical task model | 0.405× | 0.405–0.405× | False |

## Faster of the Qiskit controls

The faster Qiskit seed median is selected separately for each seed. This deliberately favors Qiskit and is not a deployed adaptive selector.

| Condition | Paired speedup | Time saving | Meets rule |
|---|---:|---:|---|
| sensor-smoke | 0.941× | -6.30% | False |
| shared-smoke | 0.432× | -131.25% | False |

## Scope and limitations

The independent angles really are updated separately. Their repeated gate occurrences are interleaved with fixed noncommuting rotations and ring entanglers. The response is a full multidimensional Fourier tensor, including mixed-sign frequencies. All response methods receive the same support, exact input identities, cache lifetime and native off-grid checks. Spatial input equivalence is not assumed.

The additional Qiskit control batches occurrence-local parameter shifts and sums them per independent parameter, using native runtime binding and exact job reuse. It avoids full response reconstruction and supplies a stronger alternative when the response table grows expensive.

Local-gate propagation removes the old dense 4^n block operators, but state storage still grows as 2^n. With p angles repeated r times each, the state coefficient count is (r+1)^p and response grid is (2r+1)^p. Chunking bounds temporary arrays; it does not remove exponential work. Library/import memory is additional to the algorithm's guarded array budget.

The batched-grid ablation tests ordinary batching. The direct adjoint control computes the identical model and all angle derivatives without persistent response reconstruction. The task-specific classical classifier uses different features and is compared on both accuracy and time. Sensor views share underlying base patterns; data seeds do not vary the architecture.

Classical coefficient propagation and native Aer calls are different costs. Fewer native calls do not establish physical CNOT, shot or hardware savings.

Worker process walls sum to 23.148 s; last parent measurement invocation: 19.718 s.
