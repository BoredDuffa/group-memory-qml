"""Independent saved-data UCI HAR audit; no project imports or model execution.

Usage: python work/audit_real_sensor.py outputs/Real_sensor/campaign
Optional --data-dir verifies selected labels/subjects and training scaler fits
against the already prepared raw-feature NPZ. It never downloads or fits PCA.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import random
import statistics as st
import subprocess
import time
import zipfile

import numpy as np

METHODS=("group_spectral","qiskit_response","classical_adjoint",
         "classical_logistic","classical_rbf","classical_mlp")
QML=METHODS[:3]
TOL=1e-10
ARCHIVE="c00b803081a5c797cd5e4b83700a9810b38d53d9d84e01917e090e1fdbc81031"


def read(path):return json.loads(Path(path).read_text())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def digest(x):return isinstance(x,str) and len(x)==64 and all(c in "0123456789abcdef" for c in x)
def finite(x):return isinstance(x,(int,float)) and math.isfinite(x)
def close(a,b,tol=TOL):
    assert finite(a) and finite(b) and abs(a-b)<=tol,(a,b)
def array(a,shape=None):
    a=np.asarray(a,dtype=float)
    assert np.isfinite(a).all()
    if shape is not None:assert a.shape==shape,(a.shape,shape)
    return a

def same(a,b,tol=TOL):
    a,b=array(a),array(b)
    assert a.shape==b.shape
    error=float(np.max(np.abs(a-b),initial=0))
    assert error<=tol,error
    return error

def train_hash(*arrays):
    h=hashlib.sha256()
    for value in arrays:
        a=np.ascontiguousarray(value)
        h.update(json.dumps({"shape":a.shape,"dtype":a.dtype.str}).encode())
        h.update(a.tobytes())
    return h.hexdigest()

def data_hash(*arrays):
    h=hashlib.sha256()
    for value in arrays:
        a=np.ascontiguousarray(value)
        h.update(str(a.shape).encode());h.update(str(a.dtype).encode());h.update(a.tobytes())
    return h.hexdigest()

def expected_plan(config):
    rng=random.Random(20261024)
    blocks=[(c,s,r) for c in config["conditions"] for s in config["seeds"] for r in range(config["repeats"])]
    rng.shuffle(blocks);plan=[]
    for c,s,r in blocks:
        methods=list(METHODS);rng.shuffle(methods)
        plan.extend(dict(condition=c["id"],experiment=c["experiment"],config=c.get("config",{}),seed=s,repeat=r,method=m) for m in methods)
    return plan

def metrics(labels,probabilities):
    labels=np.asarray(labels,dtype=np.int64)
    p=array(probabilities,(len(labels),6))
    assert (p>=0).all() and np.max(np.abs(p.sum(axis=1)-1))<=TOL
    predicted=p.argmax(axis=1)
    confusion=np.zeros((6,6),dtype=np.int64)
    np.add.at(confusion,(labels,predicted),1)
    support=confusion.sum(axis=1)
    assert (support>0).all()
    return dict(accuracy=float(np.mean(predicted==labels)),
        balanced_accuracy=float(np.mean(confusion.diagonal()/support)),
        log_loss=float(-np.mean(np.log(np.clip(p[np.arange(len(labels)),labels],1e-15,1)))),
        confusion_matrix=confusion.tolist(),class_support=support.tolist())

def check_metrics(record,expected):
    for key in ("accuracy","balanced_accuracy","log_loss"):close(record[key],expected[key])
    assert record["confusion_matrix"]==expected["confusion_matrix"]
    assert record["class_support"]==expected["class_support"]

def source_check(config,directory,repo):
    revision=directory.parent/"code_revision.json"
    commit=read(revision).get("commit") if revision.exists() else None
    for name,expected in config["source_hashes"].items():
        assert digest(expected) and not Path(name).is_absolute() and ".." not in Path(name).parts
        raw=(subprocess.check_output(["git","show",f"{commit}:src/group_memory_qml/{name}"],cwd=repo)
             if commit else (repo/"src/group_memory_qml"/name).read_bytes())
        assert sha(raw)==expected,name
    return dict(files=len(config["source_hashes"]),commit=commit,
                verification="frozen Git source" if commit else "current source hashes; no frozen commit receipt yet")

def verify_data(row,raw):
    d,cfg=row["diagnostics"],row["config"]
    p=d["provenance"]
    assert p["archive_sha256"]==ARCHIVE
    assert "license_discrepancy" in p
    assert d["subject_disjoint"] is True
    assert d["preprocessing"]["fit_scope"]=="selected_training_rows_only"
    assert digest(d["dataset_sha256"]) and digest(d["preprocessing_sha256"])
    assert sha(json.dumps(d["preprocessing"],sort_keys=True,allow_nan=False).encode())==d["preprocessing_sha256"]
    subjects=d["subjects"]
    assert not any(set(subjects[a])&set(subjects[b]) for a,b in (("train","validation"),("train","test"),("validation","test")))
    assert set(subjects["test"])<=set(p["official_test_subjects"])
    assert set(subjects["validation"])<=set(p["official_train_subjects"])
    assert set(subjects["train"])<=set(p["official_train_subjects"])
    assert not set(p["official_train_subjects"])&set(p["official_test_subjects"])
    assert set(subjects["validation"])<=set(p["validation_subject_pool"])
    assert not set(subjects["train"])&set(p["validation_subject_pool"])
    for split,nkey in (("train","n_train"),("validation","n_validation"),("test","n_test")):
        indices=p["selected_indices"][split]
        assert len(indices)==cfg[nkey] and len(set(indices))==len(indices)
        assert all(type(v) is int and v>=0 for v in indices)
        assert digest(d["split_sha256"][split])
        assert all(digest(h) for h in d["feature_sha256"][split].values())
        assert sum(p["class_counts"][split])==cfg[nkey] and min(p["class_counts"][split])>0
        if raw is not None:
            original="test" if split=="test" else "train"
            ix=np.asarray(indices,dtype=np.int64)
            y,s=raw[f"y_{original}"][ix],raw[f"subjects_{original}"][ix]
            assert train_hash(ix,s,y)==d["split_sha256"][split]
            assert data_hash(ix,s,y)==p["split_sha256"][split]
            assert sorted(np.unique(s).tolist())==subjects[split]
            assert np.bincount(y,minlength=6).tolist()==p["class_counts"][split]
            if split=="test":assert y.tolist()==d["test_labels"]
    if raw is not None:
        train=raw["X_train"][p["selected_indices"]["train"]]
        same(train.mean(axis=0),d["preprocessing"]["standardizer_mean"],1e-12)
        scale=train.std(axis=0);scale[scale==0]=1
        same(scale,d["preprocessing"]["standardizer_scale"],1e-12)
    assert data_hash(np.asarray(p["selected_indices"]["train"],dtype=np.int64))==d["preprocessing"]["fit_train_indices_sha256"]
    return None if raw is None else raw["y_train"][p["selected_indices"]["validation"]]

def qml_check(row,validation_labels):
    cfg,d=row["config"],row["diagnostics"]
    n,steps=cfg["n_qubits"],cfg["steps"]
    training,trace,validation=d["parameter_training"],d["training_trajectory"],d["validation_trajectory"]
    assert len(trace)==steps and len(validation)==steps+1
    assert [r["step"] for r in validation]==list(range(steps+1))
    assert training["independent_parameters"]==n and training["patches"]==n//2
    initial=np.r_[array(training["initial"],(n,)),array(training["initial_head_weights"],(n//2,6)).ravel(),array(training["initial_head_bias"],(6,))]
    current=initial.copy();m=np.zeros_like(initial);v=np.zeros_like(initial)
    for step,r in enumerate(trace,1):
        assert r["step"]==step
        same(r["parameters_before"],current)
        grad=array(r["gradient"],current.shape)
        m=.9*m+.1*grad;v=.999*v+.001*grad*grad
        current=current-cfg["learning_rate"]*(m/(1-.9**step))/(np.sqrt(v/(1-.999**step))+1e-8)
        same(r["parameters_after"],current)
        close(r["validation_log_loss"],validation[step]["log_loss"])
        assert finite(r["training_regularized_log_loss"]) and 0<=r["training_accuracy"]<=1
    final=np.r_[training["final"],np.asarray(training["final_head_weights"]).ravel(),training["final_head_bias"]]
    same(final,current)
    selected=min(range(len(validation)),key=lambda i:validation[i]["log_loss"])
    assert d["selected_checkpoint_step"]==selected
    best=initial if selected==0 else np.asarray(trace[selected-1]["parameters_after"])
    savedbest=np.r_[training["selected"],np.asarray(training["selected_head_weights"]).ravel(),training["selected_head_bias"]]
    same(savedbest,best)
    check_metrics(d["validation_metrics"],validation[selected])
    check_metrics(row["validation_metrics"],validation[selected])
    displacement=array(training["final"])-array(training["initial"])
    same(displacement,training["displacement"])
    same(array(training["selected"])-array(training["initial"]),training["selected_displacement"])
    assert training["moved_parameters"]==int(np.count_nonzero(np.abs(displacement)>1e-12))
    response=d["response"]
    assert d["engine"]==response
    assert response["n_qubits"]==response["n_parameters"]==n
    assert response["n_patches"]==n//2 and response["patch_qubits"]==response["patch_parameters"]==2
    assert response["parameter_occurrences_per_patch"]==2
    assert response["response_grid_points_per_patch_input"]==25
    assert response["response_state_vectors_per_patch_input"]==9
    assert response["notional_unfactorized_joint_grid_points"]==5**n
    assert response["dense_block_bytes"]==0
    for key in ("architecture_sha256","model_sha256","source_sha256","patch_source_sha256"):
        assert digest(response[key])
    assert row["evaluations"]==response["total_circuit_evaluations"]==response["native_evaluations"]+response["diagonal_evaluations"]
    assert row["total_cx"]==response["native_cx_work"]
    if row["method"]!="classical_adjoint":
        assert digest(response["patch_native_sha256"])
        assert response["check_failures"]==0 and response["max_check_error"]<=TOL and response["check_atol"]==TOL
        assert response["check_evaluations"]==2*response["cached_responses"]
        assert response["native_cx_work"]==response["native_evaluations"]*response["native_cx_per_circuit"]
    if row["method"]=="qiskit_response":
        assert digest(response["diagonal_sha256"]) and response["diagonal_bytes"]==128
        assert response["native_evaluations"]==response["check_evaluations"]
        assert response["diagonal_evaluations"]>=25*response["cached_responses"]
    strategy=d["validation_response_strategy"]
    assert strategy["warm_once"]==(row["method"] in QML[:2] and steps>=25)
    assert strategy["threshold_steps"]==25
    # Reconstruct every independently auditable segment of the stored matching
    # vector. The initial/selected validation probabilities are also checked
    # against labels when the prepared dataset is supplied.
    vector=array(row["validation_vector"]);cursor=0
    def take(count):
        nonlocal cursor
        x=vector[cursor:cursor+count];cursor+=count;assert len(x)==count;return x
    same(take(len(initial)),initial)
    close(float(take(1)[0]),validation[0]["log_loss"])
    initialp=take(cfg["n_validation"]*6).reshape(-1,6)
    if validation_labels is not None:check_metrics(validation[0],metrics(validation_labels,initialp))
    for r in trace:
        for key in ("parameters_before","gradient"):
            same(take(len(initial)),r[key])
        close(float(take(1)[0]),r["training_regularized_log_loss"])
        same(take(len(initial)),r["parameters_after"])
        close(float(take(1)[0]),r["validation_log_loss"])
    close(float(take(1)[0]),selected)
    same(take(len(initial)),best)
    bestp=take(cfg["n_validation"]*6).reshape(-1,6)
    if validation_labels is not None:check_metrics(validation[selected],metrics(validation_labels,bestp))
    testf=take(cfg["n_test"]*(n//2)).reshape(cfg["n_test"],n//2)
    testp=take(cfg["n_test"]*6).reshape(-1,6)
    assert cursor==len(vector)
    same(testp,d["test_probabilities"])
    logits=testf@np.asarray(training["selected_head_weights"])+training["selected_head_bias"]
    exp=np.exp(logits-logits.max(axis=1,keepdims=True))
    same(exp/exp.sum(axis=1,keepdims=True),testp)
    maxgradient=np.max(np.abs(np.asarray([r["gradient"][:n] for r in trace])),axis=0)
    return dict(moved_parameters=int(np.count_nonzero(np.abs(displacement)>1e-12)),
        selected_moved_parameters=int(np.count_nonzero(np.abs(np.asarray(training["selected_displacement"]))>1e-12)),
        displacement_norm=float(np.linalg.norm(displacement)),maximum_absolute_theta_gradient=maxgradient.tolist(),
        selected_step=selected)

def classical_check(row):
    d=row["diagnostics"]
    assert row["evaluations"]==row["total_cx"]==0
    assert d["parameter_training"] is None and not d["engine"]
    candidates=d["classical_candidates"]
    assert [c["view"] for c in candidates]==["angles","full561"]
    for c in candidates:
        assert c["method"]==row["method"]
        assert finite(c["fit_s"]) and c["fit_s"]>=0
        assert finite(c["validation_predict_s"]) and c["validation_predict_s"]>=0
    selected=min(range(2),key=lambda i:candidates[i]["validation_metrics"]["log_loss"])
    assert d["selected_feature_view"]==candidates[selected]["view"]
    check_metrics(d["validation_metrics"],candidates[selected]["validation_metrics"])
    close(d["timings"]["candidate_fit_s"],sum(c["fit_s"] for c in candidates))
    close(d["timings"]["candidate_validation_s"],sum(c["validation_predict_s"] for c in candidates))

def checkpoint_check(directory,config,auth,count):
    manifest=read(directory/"checkpoints/manifest.json")
    assert manifest["completed_attempts"]==count and manifest["deadline_unix"]==auth["deadline_unix"]
    for slot in ("latest","previous"):
        if not manifest.get(slot):continue
        cpfile=directory/"checkpoints"/manifest[slot]
        if slot=="latest":assert sha(cpfile.read_bytes())==manifest["latest_sha256"]
        cp=read(cpfile);n=cp["completed_attempts"]
        assert cp["config_sha256"]==sha((directory/"config.json").read_bytes())
        assert cp["deadline_unix"]==auth["deadline_unix"]
        assert cp["journal_last_index"]==n-1
        assert cp["next_spec"]==(config["plan"][n] if n<len(config["plan"]) else None)
        assert set(cp["journal_sha256"])=={f"{i:05d}.json" for i in range(n)}
        for name,h in cp["journal_sha256"].items():assert sha((directory/"attempts"/name).read_bytes())==h
        assert cp["last_result_sha256"]==cp["journal_sha256"][f"{n-1:05d}.json"]
    best=directory/"checkpoints/most_complete.json"
    assert best.read_bytes()==(directory/"checkpoints"/manifest["latest"]).read_bytes()

def audit(directory,repo,data_dir):
    directory=directory.resolve()
    config,status,auth=[read(directory/(x+".json")) for x in ("config","status","authorization")]
    assert status["status"] in ("COMPLETE","BUDGET_EXHAUSTED","CHECKPOINTED")
    assert config["plan"]==expected_plan(config)
    assert auth["deadline_unix"]==min(auth["start_unix"]+config["budget_s"],config.get("hard_deadline_unix",float("inf")))
    assert status["deadline_unix"]==auth["deadline_unix"]
    source=source_check(config,directory,repo)
    raw=None
    if data_dir:
        for name,h in config["data_sha256"].items():assert sha((data_dir/name).read_bytes())==h
        with np.load(data_dir/"har_features.npz",allow_pickle=False) as z:raw={name:z[name] for name in z.files}
    rows,blocks,motion,signature={}, {}, {}, {}
    last_end=auth["start_unix"]
    for i,spec in enumerate(config["plan"]):
        path=directory/"attempts"/f"{i:05d}.json"
        row=read(path) if path.exists() else dict(spec=spec,status="UNATTEMPTED")
        assert row["spec"]==spec
        rows[i]=row;key=(spec["condition"],spec["seed"],spec["repeat"])
        assert spec["method"] not in blocks.setdefault(key,{})
        blocks[key][spec["method"]]=row
        if row["status"]=="UNATTEMPTED":continue
        assert row["status"] in ("SUCCESS","ERROR","TIMEOUT")
        assert finite(row["process_wall_s"]) and row["process_wall_s"]>0
        assert last_end<=row["attempt_start_unix"]<auth["deadline_unix"]
        assert row["attempt_end_unix"]>=row["attempt_start_unix"]
        close(row["attempt_end_unix"]-row["attempt_start_unix"],row["process_wall_s"],.1)
        last_end=row["attempt_end_unix"]
        if row["status"]!="SUCCESS":continue
        assert row["attempt_end_unix"]<=auth["deadline_unix"]
        assert row["source_hashes"]==config["source_hashes"]
        assert all(row[k]==spec[k] for k in ("method","seed"))
        experiment_names={"uci_har":"real_sensor","real_sensor":"real_sensor"}
        assert spec["experiment"] in experiment_names
        assert row["experiment"]==experiment_names[spec["experiment"]]
        assert all(row["config"].get(k)==v for k,v in spec["config"].items())
        assert row["n_qubits"]==row["config"]["n_qubits"]
        for clock in ("application_s","worker_before_write_s","import_and_setup_s"):
            assert finite(row[clock]) and row[clock]>0
        assert row["application_s"]<=row["worker_before_write_s"]<=row["process_wall_s"]
        assert row["import_and_setup_s"]+row["application_s"]<=row["worker_before_write_s"]
        d=row["diagnostics"]
        assert d["test_evaluations"]==1
        timing=d["timing"]
        assert timing["load_split_preprocess_hash_s"]+timing["train_select_test_s"]<=row["application_s"]
        assert sum(d["timings"].values())<=timing["train_select_test_s"]
        assert all(finite(v) and v>=0 for v in d["timings"].values())
        assert d["dataset_timings"]["total_preparation_s"]<=timing["load_split_preprocess_hash_s"]
        validation_labels=verify_data(row,raw)
        assert d["provenance"]["prepared_npz_sha256"]==config["data_sha256"]["har_features.npz"]
        expected=metrics(d["test_labels"],d["test_probabilities"])
        check_metrics(row["test_metrics"],expected);check_metrics(d["test_metrics"],expected)
        assert d["test_predictions"]==np.asarray(d["test_probabilities"]).argmax(axis=1).tolist()
        close(row["metric_value"],expected["balanced_accuracy"])
        if row["method"] in QML:
            motion[(*key,row["method"])]=qml_check(row,validation_labels)
            response=d["response"]
            for field in ("source_sha256","architecture_sha256","patch_source_sha256","patch_native_sha256","diagonal_sha256"):
                value=response[field]
                identity=(spec["condition"],row["method"],field)
                assert signature.setdefault(identity,value)==value
        else:classical_check(row)
    count=sum(r["status"]!="UNATTEMPTED" for r in rows.values())
    assert [i for i,r in rows.items() if r["status"]!="UNATTEMPTED"]==list(range(count))
    assert status["completed_attempts"]==count
    assert status["planned_attempts"]==len(rows) and status.get("unattempted",len(rows)-count)==len(rows)-count
    if count:checkpoint_check(directory,config,auth,count)
    good,worst=set(),0.
    for key,block in blocks.items():
        successes=[r for r in block.values() if r["status"]=="SUCCESS"]
        for field in ("dataset_sha256","preprocessing_sha256"):
            assert len({r["diagnostics"][field] for r in successes})<=1
        assert len({json.dumps(r["diagnostics"]["split_sha256"],sort_keys=True) for r in successes})<=1
        if any(block[m]["status"]!="SUCCESS" for m in QML):continue
        ref=block["qiskit_response"]
        for m in QML:
            r=block[m]
            worst=max(worst,same(r["validation_vector"],ref["validation_vector"]))
            assert r["diagnostics"]["test_predictions"]==ref["diagnostics"]["test_predictions"]
            for field in ("source_sha256","architecture_sha256","patch_source_sha256","model_sha256"):
                assert r["diagnostics"]["response"][field]==ref["diagnostics"]["response"][field]
        assert block["group_spectral"]["diagnostics"]["response"]["patch_native_sha256"]==ref["diagnostics"]["response"]["patch_native_sha256"]
        good.add(key)
    seeds={}
    for c in config["conditions"]:
        for s in config["seeds"]:
            keys=[(c["id"],s,r) for r in range(config["repeats"])]
            if not all(k in good for k in keys):continue
            for m in METHODS:
                selected=[blocks[k][m] for k in keys]
                if not all(r["status"]=="SUCCESS" for r in selected):continue
                # Replicates are timing repeats, not new test samples.
                assert max(r["metric_value"] for r in selected)-min(r["metric_value"] for r in selected)<=TOL
                seeds[c["id"],s,m]=dict(process_wall_s=st.median(r["process_wall_s"] for r in selected),
                    balanced_accuracy=st.median(r["metric_value"] for r in selected),
                    log_loss=st.median(r["test_metrics"]["log_loss"] for r in selected),
                    selected_step=selected[0]["diagnostics"].get("selected_checkpoint_step"),
                    selected_view=selected[0]["diagnostics"].get("selected_feature_view"))
    comparisons=[]
    for c in config["conditions"]:
        cid=c["id"]
        for m in METHODS[1:]:
            common=[s for s in config["seeds"] if (cid,s,"group_spectral") in seeds and (cid,s,m) in seeds]
            if not common:continue
            ratios=[seeds[cid,s,m]["process_wall_s"]/seeds[cid,s,"group_spectral"]["process_wall_s"] for s in common]
            differences=[seeds[cid,s,"group_spectral"]["balanced_accuracy"]-seeds[cid,s,m]["balanced_accuracy"] for s in common]
            savings=[1-1/r for r in ratios]
            runtime_win=len(common)>=5 and config["repeats"]>=2 and min(ratios)>1 and st.median(savings)>=.05
            comparisons.append(dict(condition=cid,baseline=m,matched_seeds=len(common),
                paired_speedup=st.median(ratios),minimum_seed_speedup=min(ratios),maximum_seed_speedup=max(ratios),
                median_paired_saving=st.median(savings),runtime_win=runtime_win,
                minimum_balanced_accuracy_difference=min(differences),mean_balanced_accuracy_difference=st.mean(differences),
                useful_win=runtime_win and min(differences)>=-TOL,
                per_seed=[dict(seed=s,speedup=r,balanced_accuracy_difference=q) for s,r,q in zip(common,ratios,differences)]))
    movement={}
    for c in config["conditions"]:
        values=[v for (cid,s,r,m),v in motion.items() if cid==c["id"] and r==0 and m=="group_spectral"]
        if values:
            movement[c["id"]]=dict(observed_seeds=len(values),
                min_moved_parameters=min(v["moved_parameters"] for v in values),
                max_moved_parameters=max(v["moved_parameters"] for v in values),
                min_selected_moved_parameters=min(v["selected_moved_parameters"] for v in values),
                max_selected_moved_parameters=max(v["selected_moved_parameters"] for v in values),
                median_displacement_norm=st.median(v["displacement_norm"] for v in values),
                selected_steps=[v["selected_step"] for v in values])
    return dict(audit="PASS",source=source,raw_data_verified=raw is not None,
        planned=len(rows),attempted=count,successful=sum(r["status"]=="SUCCESS" for r in rows.values()),
        matched_blocks=len(good),planned_blocks=len(blocks),maximum_matching_vector_error=worst,
        coverage={c["id"]:dict(Counter(r["status"] for r in rows.values() if r["spec"]["condition"]==c["id"])) for c in config["conditions"]},
        authorization=auth,latest_attempt_end_unix=last_end,
        worker_wall_sum_s=sum(r.get("process_wall_s",0) for r in rows.values()),
        parameter_motion=movement,comparisons=comparisons,
        seed_medians=[dict(condition=key[0],seed=key[1],method=key[2],**value) for key,value in seeds.items()],
        limits=["Independent two-qubit patches; nominal8/16 qubits are not a fully entangled statevector or a hardware advantage.",
                "The same-model vector verifies optimizer parameters/gradients and selected final predictions, not every intermediate feature Jacobian.",
                "Seed subsets share subjects across replicates; no confidence interval or independent-subject significance claim.",
                "Common archive download/text preparation is separate from each timed NPZ read and train-only preprocessing.",
                "Partial blocks and incomplete repeat sets never support wins."])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("campaign",type=Path)
    parser.add_argument("--repo",type=Path,default=Path(__file__).resolve().parent.parent/"group-memory-qml")
    parser.add_argument("--data-dir",type=Path)
    parser.add_argument("--output",type=Path)
    args=parser.parse_args();started=time.perf_counter()
    result=audit(args.campaign,args.repo,args.data_dir)
    result["audit_seconds"]=time.perf_counter()-started
    destination=args.output or args.campaign.parent/(args.campaign.name+"_independent_audit.json")
    assert "group-memory-qml" not in destination.resolve().parts
    destination.write_text(json.dumps(result,indent=2,allow_nan=False)+"\n")
    print(json.dumps({k:result[k] for k in ("audit","planned","attempted","successful","matched_blocks","maximum_matching_vector_error","audit_seconds")},indent=2))
    print(f"Receipt: {destination}")

if __name__=="__main__":main()
