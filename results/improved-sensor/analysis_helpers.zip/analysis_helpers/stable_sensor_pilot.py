"""Validation-only Adam stability search; never opens the final-test NPZ members.

This exploratory lockstep comparison is not a performance benchmark. Every
method advances its own parameters. No rounding or relaxed correctness checks.
Raw gradients, parameters and validation probabilities are retained in NPZ
receipts; the JSON contains hashes, raw-witness errors and validation metrics.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'work/stable_sensor_pilot.json'
TRACES = ROOT / 'work/stable_sensor_pilot_traces'


def write_json(value):
    tmp = OUTPUT.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False))
    tmp.replace(OUTPUT)


def child(deadline):
    started = time.perf_counter()
    import numpy as np
    from threadpoolctl import threadpool_limits
    threadpool_limits(1)
    from group_memory_qml.improved_sensor_data import load_improved_sensor_dataset
    from group_memory_qml.real_sensor_model import PatchResponseModel
    from group_memory_qml.real_sensor_training import _softmax, _metrics, _loss_gradients, _pack, _unpack
    TRACES.mkdir(exist_ok=True)
    report = dict(status='RUNNING', tolerance=1e-10, validation_only=True,
                  test_arrays_accessed=False, test_predictions_computed=False,
                  source_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  source_revision='a0f8cb5fc67845c0be30ea08cc51dac782b8ac96',
                  steps=1000, n_train=512, n_validation=128, n_features=16,
                  representation='lda_tiled', angle_scale=.5, head_l2=1e-4,
                  seeds=[956101,956102,956103,956104,956105], records=[],
                  numerical_policy='Independent Adam states, no rounding; raw absolute error <=1e-10 at every step',
                  timing_scope='Shared exploratory process; not final per-method timing. External parent launch includes imports.',
                  trace_layout='train_loss,validation_log_loss,gradient[70],updated_parameters[70],validation_probabilities[128,6]')
    datasets = {}
    write_json(report)

    def pair(seed, epsilon, learning_rate, second='qiskit_response'):
        if time.time() > deadline-15:
            return None
        tick = time.perf_counter()
        if seed not in datasets:
            datasets[seed] = load_improved_sensor_dataset(
                ROOT/'work/data/uci_har', n_train=512, n_validation=128,
                n_test=256, seed=seed, n_features=16,
                representation='lda_tiled', angle_scale=.5, validation_only=True)
        d = datasets[seed]
        methods = ['group_spectral', second]
        rng=np.random.default_rng(np.random.SeedSequence([seed,61527]))
        theta=rng.uniform(-.7,.7,16)
        head=rng.normal(0,.1,(8,6))
        initial=_pack(theta,head,np.zeros(6))
        states=[]
        for method in methods:
            model=PatchResponseModel(16, method=method, occurrences=2)
            f,_=model.evaluate(d.validation_angles,theta,gradient=method!='classical_adjoint')
            vp=_softmax(f@head)[0]
            vm=_metrics(d.y_validation,vp)
            states.append(dict(model=model,params=initial.copy(),m=np.zeros_like(initial),v=np.zeros_like(initial),
                               best_loss=vm['log_loss'], best_step=0, best_params=initial.copy(),
                               best_prob=vp.copy(),best_metrics=vm,trace=[],initial_prob=vp.copy()))
        record=dict(seed=seed,epsilon=epsilon,learning_rate=learning_rate,methods=methods,
                    status='RUNNING', completed_steps=0, errors=[], max_error=0.0,
                    max_errors=dict(gradient=0.,parameters=0.,validation_probabilities=0.,losses=0.),
                    initial_probability_maxerror=float(np.max(np.abs(states[0]['initial_prob']-states[1]['initial_prob']))))
        for step in range(1,1001):
            if time.time() > deadline-3:
                record['status']='BUDGET_EXHAUSTED'; break
            rows=[]
            for state in states:
                theta,head,bias=_unpack(state['params'],16)
                f,j=state['model'].evaluate(d.train_angles,theta,gradient=True)
                loss,_,gt,gw,gb=_loss_gradients(f,j,d.y_train,head,bias,1e-4)
                gradient=_pack(gt,gw,gb)
                state['m']=.9*state['m']+.1*gradient
                state['v']=.999*state['v']+.001*gradient*gradient
                state['params']=state['params']-learning_rate*(state['m']/(1-.9**step))/(np.sqrt(state['v']/(1-.999**step))+epsilon)
                theta,head,bias=_unpack(state['params'],16)
                f,_=state['model'].evaluate(d.validation_angles,theta,gradient=False)
                vp=_softmax(f@head+bias)[0]
                vm=_metrics(d.y_validation,vp)
                row=np.concatenate(([loss,vm['log_loss']],gradient,state['params'],vp.ravel()))
                state['trace'].append(row); rows.append(row)
                if vm['log_loss'] < state['best_loss']:
                    state.update(best_loss=vm['log_loss'],best_step=step,best_params=state['params'].copy(),best_prob=vp.copy(),best_metrics=vm)
            diff=np.abs(rows[0]-rows[1])
            values=dict(gradient=float(diff[2:72].max()),parameters=float(diff[72:142].max()),
                        validation_probabilities=float(diff[142:].max()),losses=float(diff[:2].max()))
            err=float(diff.max())
            record['errors'].append(dict(step=step,**values))
            record['max_error']=max(record['max_error'],err)
            record['completed_steps']=step
            for key,value in values.items(): record['max_errors'][key]=max(record['max_errors'][key],value)
            if err>1e-10:
                record.update(status='FAIL',first_failing_step=step,worst_component_index=int(diff.argmax()),
                              witness_values=[float(row[diff.argmax()]) for row in rows])
                # Same common point distinguishes evaluator accuracy from optimizer trajectory sensitivity.
                common_theta,common_head,common_bias=_unpack(states[0]['params'],16)
                common=[]
                for state in states:
                    cf,cj=state['model'].evaluate(d.train_angles,common_theta,gradient=True)
                    _,_,cgt,cgw,cgb=_loss_gradients(cf,cj,d.y_train,common_head,common_bias,1e-4)
                    common.append((cf,cj,_pack(cgt,cgw,cgb)))
                record['common_point_max_errors']={name:float(np.max(np.abs(common[0][i]-common[1][i]))) for i,name in enumerate(['features','jacobian','gradient'])}
                break
        else:
            record['status']='PASS'
        record['selected_checkpoints']=[dict(method=m,step=s['best_step'],validation_metrics=s['best_metrics']) for m,s in zip(methods,states)]
        record['selected_params_maxerror']=float(np.max(np.abs(states[0]['best_params']-states[1]['best_params'])))
        record['selected_validation_probability_maxerror']=float(np.max(np.abs(states[0]['best_prob']-states[1]['best_prob'])))
        record['selected_steps_match']=states[0]['best_step']==states[1]['best_step']
        if record['status']=='PASS' and (not record['selected_steps_match'] or max(record['selected_params_maxerror'],record['selected_validation_probability_maxerror'])>1e-10):
            record['status']='FAIL_SELECTED_CHECKPOINT'
        name=f"seed{seed}_eps{epsilon:g}_lr{learning_rate:g}_{second}.npz"
        path=TRACES/name
        np.savez(path,method0=np.asarray(states[0]['trace']),method1=np.asarray(states[1]['trace']),
                 initial_params=initial,initial_validation0=states[0]['initial_prob'],initial_validation1=states[1]['initial_prob'],
                 selected_params0=states[0]['best_params'],selected_params1=states[1]['best_params'],
                 selected_validation0=states[0]['best_prob'],selected_validation1=states[1]['best_prob'])
        record['trace_artifact']=dict(path=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size)
        record['seconds']=time.perf_counter()-tick
        record['engine_checks_maxerror']=[float(s['model'].diagnostics['max_check_error']) for s in states]
        report['records'].append(record);report['inner_wall_s']=time.perf_counter()-started
        write_json(report)
        print(json.dumps({k:record[k] for k in ['seed','epsilon','learning_rate','methods','status','completed_steps','max_error','seconds']}),flush=True)
        return record

    pair(956102,1e-8,.03)
    chosen=None
    # Preserve original learning rate unless no epsilon candidate succeeds.
    for lr,eps in [(0.03,1e-6),(0.03,1e-4),(0.01,1e-6),(0.01,1e-4)]:
        group=[]
        for seed in [956102,956101,956103,956104,956105]:
            record=pair(seed,eps,lr)
            if record is None or record['status']!='PASS': break
            group.append(record)
        if len(group)==5:
            chosen=dict(epsilon=eps,learning_rate=lr,all_five_response_seeds_pass=True,
                        max_raw_error=max(r['max_error'] for r in group),
                        mean_selected_validation_balanced_accuracy=float(np.mean([r['selected_checkpoints'][0]['validation_metrics']['balanced_accuracy'] for r in group])),
                        mean_selected_validation_log_loss=float(np.mean([r['selected_checkpoints'][0]['validation_metrics']['log_loss'] for r in group])))
            break
        if time.time()>deadline-20: break
    report['selected_candidate']=chosen
    if chosen and time.time()<deadline-65:
        adjoint=pair(956102,chosen['epsilon'],chosen['learning_rate'],second='classical_adjoint')
        chosen['adjoint_worst_seed_status']=None if adjoint is None else adjoint['status']
        if adjoint is not None and adjoint['status']!='PASS': chosen['all_methods_validated']=False
    report['status']='STABLE_RESPONSE_CANDIDATE' if chosen else 'NO_FULLY_VALIDATED_CANDIDATE'
    report['inner_wall_s']=time.perf_counter()-started
    write_json(report)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--child',action='store_true');parser.add_argument('--deadline',type=float)
    args=parser.parse_args()
    if args.child: return child(args.deadline)
    started=time.perf_counter();start_unix=time.time()
    env=os.environ.copy()
    env['PYTHONPATH']=str(ROOT/'group-memory-qml/src')
    for name in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS','RAYON_NUM_THREADS']:env[name]='1'
    proc=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--child','--deadline',str(start_unix+285)],env=env,timeout=295)
    receipt=json.loads(OUTPUT.read_text()) if OUTPUT.exists() else {'status':'NO_CHILD_RECEIPT'}
    receipt['external_process_wall_s']=time.perf_counter()-started
    receipt['external_start_unix']=start_unix;receipt['external_end_unix']=time.time();receipt['returncode']=proc.returncode
    receipt['external_clock_includes']='child startup/imports, all data transforms, search, strict checks, raw artifact serialization and child exit; parent final JSON write follows clock'
    write_json(receipt)
    return proc.returncode

if __name__=='__main__': raise SystemExit(main())
