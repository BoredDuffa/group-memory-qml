# Rejected initial improved-sensor run

This archive preserves100 completed attempts from source a0f8cb5fc67845c0be30ea08cc51dac782b8ac96. The independent audit is FAIL.

Full cross-engine trajectories differed by up to0.03408229468145725 against the unchanged1e-10 requirement. A separate UTC-versus-monotonic timing-enclosure check also failed. Identical final classification accuracy did not rescue those failures. No qualifying performance or useful-win claim from this run is valid.

All original full-vector attempt JSON bytes are preserved in the four rejected_attempts_*.zip archives; configuration, status, authorization, environment, checkpoint and audit bytes are preserved here. Extract the metadata and all four attempt archives into one directory to restore the complete original campaign tree. The original checksum links are verified. Top-level CSVs use the later strict audit gate. The rejected_ungated folder preserves the old invalid win flags and original summary receipt for transparency; those flags must never be presented as accepted results. Its explicitly named reconstructed summary CSV reproduces the original receipt values, not a claim about original CSV bytes.

Use rejected_source_snapshot.zip for exact frozen code. Its32 campaign source hashes are verified against the original configuration. Every ZIP has an internal SHA256SUMS.json manifest. ATTEMPT_ARCHIVES.json identifies all four full-vector shards and their archive hashes. No raw sensor dataset, private paths or secrets are included.

The test set was256 class-balanced rows excluding previously evaluated rows and immediate same-subject neighbors, but it uses existing test subjects. Any subsequent correctness-recovery rerun reuses this evaluated holdout. Keep this failed run and its costs separate from repaired-run timings; retain its cost in total study accounting. CPU simulation, supervised classical LDA, five intrinsic representation axes and independent two-qubit patches do not establish a QPU or practical quantum advantage.
