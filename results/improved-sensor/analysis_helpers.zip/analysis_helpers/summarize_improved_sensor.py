"""Saved-data paired summaries with a fail-closed independent-audit gate.

This helper never imports or executes the experiment. Runtime/quality columns
remain descriptive when an audit fails; qualifying win flags are always false.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import statistics as st
import time

BASE = Path(__file__).resolve().parent.parent
DEFAULT = BASE / 'outputs/Improved_sensor_benchmark'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_csv(output, name, rows):
    if rows:
        with (output/name).open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


def audit_gate(audit, rows, config):
    reasons = []
    if audit is None:
        return False, ['Independent audit receipt is missing']
    if audit.get('status') != 'PASS':
        reasons.append('Independent audit status is not PASS')
    if audit.get('errors') != []:
        reasons.append('Independent audit errors are present or unavailable')
    planned = len(config['plan'])
    successful = sum(row.get('status') == 'SUCCESS' for row in rows)
    if audit.get('complete_successful_coverage') is not True:
        reasons.append('Independent audit does not confirm complete successful coverage')
    for key, expected in (('planned_attempts', planned), ('attempted_attempts', len(rows)),
                          ('successful_attempts', successful), ('missing_attempts', 0)):
        if audit.get(key) != expected:
            reasons.append(f'Independent audit {key} does not match selected campaign')
    if len(rows) != planned or successful != planned:
        reasons.append('Selected campaign has incomplete or unsuccessful attempts')
    error = audit.get('max_matching_error')
    if not isinstance(error, (int, float)) or not math.isfinite(error) or not 0 <= error <= 1e-10:
        reasons.append('Full matched-trajectory agreement is absent or exceeds 1e-10')
    return not reasons, reasons


def parent_loop_costs(campaign, files, rows):
    """Verify saved parent-loop receipts; never allocate missing overhead."""
    root = campaign/'attempt_costs'
    manifest_path = root/'manifest.json'
    if not manifest_path.exists():
        return {}, False, 'Parent-loop sidecars unavailable; no overhead allocation invented', {}
    manifest = read(manifest_path)
    config_sha = sha(campaign/'config.json')
    if manifest.get('config_sha256') != config_sha or manifest.get('completed_attempts') != len(rows):
        raise ValueError('Parent-loop manifest configuration/count mismatch')
    status = read(campaign/'status.json')
    if status.get('attempt_cost_manifest_sha256') != sha(manifest_path):
        raise ValueError('Terminal status does not bind the parent-loop manifest')
    values, hashes = {}, {}
    expected_names = {path.name for path in files}
    if set(manifest.get('sidecar_sha256', {})) != expected_names:
        raise ValueError('Parent-loop sidecar inventory mismatch')
    for path, row in zip(files, rows):
        sidecar = root/path.name
        if sha(sidecar) != manifest['sidecar_sha256'][path.name]:
            raise ValueError('Parent-loop sidecar checksum mismatch')
        cost = read(sidecar)
        if (cost.get('config_sha256') != config_sha or cost.get('result_sha256') != sha(path)
                or cost.get('spec') != row['spec'] or cost.get('attempt_index') != int(path.stem)):
            raise ValueError('Parent-loop sidecar does not bind this exact attempt')
        duration = cost.get('parent_loop_wall_s')
        if not isinstance(duration, (float, int)) or not math.isfinite(duration) or duration <= 0:
            raise ValueError('Invalid parent-loop duration')
        if abs(cost['process_wall_s']-row['process_wall_s']) > 1e-10 or duration < row['process_wall_s']:
            raise ValueError('Parent-loop duration does not enclose process duration')
        if abs(duration-(cost['loop_end_monotonic_s']-cost['loop_start_monotonic_s'])) > 1e-8:
            raise ValueError('Parent-loop monotonic timestamps do not reproduce duration')
        values[path.name] = duration
        hashes[path.name] = sha(sidecar)
    return values, True, '', hashes


def study_cost_ledger(study_root, current_phases, search):
    """Add disjoint recorded study components, never their nested timers."""
    prior_path = DEFAULT/'timing_accounting.json'
    prior = read(prior_path) if study_root.resolve() != DEFAULT.resolve() and prior_path.exists() else {}
    prior_phases = prior.get('phases', {})
    components, intervals = [], []
    def add(name, seconds, source, scope, start=None, end=None):
        if not isinstance(seconds, (int,float)) or not math.isfinite(seconds) or seconds < 0:
            raise ValueError(f'Invalid study cost component {name}')
        components.append(dict(component=name, seconds=seconds, source=source, scope=scope))
        if isinstance(start,(int,float)) and isinstance(end,(int,float)):
            if not math.isfinite(start+end) or end < start:
                raise ValueError(f'Invalid study component interval {name}')
            intervals.append((start,end,name))
    report_words = ('report','package','readout','build','audit','summary')
    reporting = {}
    for category, phases in (('prior_rejected', prior_phases), ('current',current_phases)):
        for name, phase in sorted(phases.items()):
            if any(word in name.lower() for word in report_words):
                reporting[f'{category}/{name}'] = phase
                continue
            add(f'{category}/{name}',phase['seconds'],f'{category}/{name}_wall.json',
                'External complete phase process; inner workers/loops/stages are not added',
                phase.get('start_unix'),phase.get('end_unix'))
    stability, stability_sum = {}, 0.0
    stability_summary_path = study_root/'stable_sensor_search_summary.json'
    stability_summary = read(stability_summary_path) if stability_summary_path.exists() else {}
    for name in ('stable_sensor_pilot','stable_sensor_confirmation','stable_sensor_lower_lr'):
        path = study_root/(name+'.json')
        if not path.exists():
            continue
        record = read(path)
        expected = stability_summary.get('receipts',{}).get(path.name)
        if expected is not None and sha(path) != expected:
            raise ValueError('Numerical-stability search receipt hash mismatch')
        compact = {key:record.get(key) for key in ('status','external_process_wall_s',
                    'external_start_unix','external_end_unix','external_clock_includes')}
        compact['sha256'] = sha(path)
        stability[name] = compact
        duration = record['external_process_wall_s']
        add('stability_search/'+name,duration,path.name,
            'External process duration; per-candidate and inner-search times are nested and excluded',
            record.get('external_start_unix'),record.get('external_end_unix'))
        stability_sum += duration
    if len(stability)==3 and stability_summary.get('external_process_wall_s') is not None:
        if abs(stability_sum-stability_summary['external_process_wall_s']) > 1e-8:
            raise ValueError('Three stability search receipts do not reproduce recorded total')
    search_s = search.get('elapsed_s',prior.get('search_recorded_inner_s'))
    if search_s is not None:
        add('original_representation_search_inner',search_s,'sensor_improved_design.json',
            'Recorded inner search only; unmeasured imports/startup are explicitly excluded')
    acquisition_s = prior.get('common_acquisition_components_s',29.555855)
    add('historical_common_acquisition_components',acquisition_s,
        'original prepared-data timing receipt','Sum of download/extraction/parse/write components; not an observed whole acquisition wall')
    intervals.sort()
    for previous,current in zip(intervals,intervals[1:]):
        if current[0] < previous[1]:
            raise ValueError(f'Cannot add overlapping external phase receipts: {previous[2]} and {current[2]}')
    focused_path=study_root/'focused_test_receipt.json'
    focused=read(focused_path) if focused_path.exists() else None
    # Report/build/package costs are outside the experiment and may not exist
    # until after this ledger is frozen. Preserve present receipts separately;
    # do not silently add them to a total without verifying their overlap.
    for path in sorted(study_root.glob('*.json')):
        if ('receipt' in path.stem.lower() and any(word in path.stem.lower() for word in report_words)
                and path.name not in ('summary_receipt.json','summary_receipt_audit_gated.json')):
            record=read(path)
            clocks={key:value for key,value in record.items()
                    if isinstance(value,(int,float)) and any(word in key.lower() for word in ('seconds','elapsed','wall','duration'))}
            if clocks:
                reporting[path.name]=dict(clocks=clocks,sha256=sha(path),included_in_component_total=False)
    return dict(status='PARTIAL_RECORDED_NONOVERLAPPING_COMPONENTS',
        prior_rejected_study_phases=prior_phases,
        prior_rejected_phase_sum_s=sum(p['seconds'] for name,p in prior_phases.items()
                                       if not any(word in name.lower() for word in report_words)),
        prior_rejected_main_external_s=prior_phases.get('main',{}).get('seconds'),
        numerical_stability_search_receipts=stability,
        numerical_stability_search_external_sum_s=stability_sum if stability else None,
        current_study_phases=current_phases,
        recorded_nonoverlapping_components=components,
        recorded_nonoverlapping_components_sum_s=sum(c['seconds'] for c in components),
        verified_external_phase_intervals=len(intervals),
        focused_test_excluded_for_overlap=focused,
        reporting_helper_costs_separate=reporting,
        accounting_rule='Add external phase processes once, the original inner representation search once, and historical acquisition components once. Do not add nested attempt process, parent-loop, worker, application, fit, validation, or candidate timings. The3.85s focused test overlaps full preflight and is not additive. Reporting/package receipts remain separate.',
        interpretation='Partial sum of recorded nonoverlapping components, not complete end-to-end elapsed study wall or fully loaded development cost. External intervals were checked for overlap; search/acquisition components have distinct earlier scopes without complete enclosing clocks.',
        unmeasured_or_not_added=['Original representation-search imports/startup','Installation/runtime setup',
            'Human and AI development time','Idle/orchestration gaps between phases',
            'Historical sensor collection and author feature extraction','Unmeasured reporting/packaging or other helper work',
            'Separately displayed report/package costs whose overlap is not certified'])


def summarize(campaign, output, audit_path, wall_path=None):
    started = time.perf_counter()
    output.mkdir(parents=True, exist_ok=True)
    config = read(campaign/'config.json')
    files = sorted(path for path in (campaign/'attempts').glob('*.json') if not path.name.endswith('.worker.json'))
    rows = [read(path) for path in files]
    audit = read(audit_path) if audit_path.exists() else None
    accepted, reasons = audit_gate(audit, rows, config)
    loop_values, loops_available, loop_reason, loop_hashes = parent_loop_costs(campaign, files, rows)
    row_loop = {id(row): loop_values.get(path.name) for path, row in zip(files, rows)}
    required_repeats = config['repeats']
    if type(required_repeats) is not int or required_repeats < 1:
        raise ValueError('Invalid planned repeat count')
    groups = {}
    for row in rows:
        if row.get('status') != 'SUCCESS':
            continue
        if row.get('test_metrics') is None:
            raise ValueError('This summary is for final-test runs, not validation-only pilots')
        duration = row['process_wall_s']
        if not isinstance(duration, (int, float)) or not math.isfinite(duration) or duration <= 0:
            raise ValueError('Invalid process duration')
        key = (row['spec']['condition'], row['method'], row['seed'])
        groups.setdefault(key, []).append(row)
    seeds = []
    for (condition, method, seed), rs in sorted(groups.items()):
        accuracies = [r['test_metrics']['balanced_accuracy'] for r in rs]
        if not all(math.isfinite(a) and 0 <= a <= 1 for a in accuracies):
            raise ValueError('Invalid accuracy')
        if max(accuracies)-min(accuracies) > 1e-10:
            raise ValueError('Repeated identical fit has different accuracy')
        repeats = [r['spec']['repeat'] for r in rs]
        complete = sorted(repeats) == list(range(required_repeats))
        seeds.append(dict(condition=condition, method=method, seed=seed,
            process_s=st.median(r['process_wall_s'] for r in rs), balanced_accuracy=st.mean(accuracies),
            parent_loop_s=st.median(row_loop[id(r)] for r in rs) if loops_available else None,
            repeats=len(rs), complete_matching_repeats=complete,
            selected_step=rs[0]['diagnostics'].get('selected_checkpoint_step', ''),
            selected_view=rs[0]['diagnostics'].get('selected_feature_view', ''),
            fit_steps=rs[0]['diagnostics'].get('completed_steps', ''),
            audit_status=audit.get('status', 'UNKNOWN') if audit else 'MISSING', audit_accepted=accepted))
    summary = []
    for condition, method in sorted({(s['condition'], s['method']) for s in seeds}):
        ss = [s for s in seeds if (s['condition'], s['method']) == (condition, method)]
        steps = [s['selected_step'] for s in ss if isinstance(s['selected_step'], (int, float))]
        summary.append(dict(condition=condition, method=method, seeds=len(ss),
            attempts=sum(s['repeats'] for s in ss), median_process_s=st.median(s['process_s'] for s in ss),
            mean_balanced_accuracy=st.mean(s['balanced_accuracy'] for s in ss),
            min_balanced_accuracy=min(s['balanced_accuracy'] for s in ss),
            max_balanced_accuracy=max(s['balanced_accuracy'] for s in ss),
            mean_selected_step=st.mean(steps) if steps else '', audit_accepted=accepted))
    comparisons = []
    for condition in sorted({s['condition'] for s in seeds}):
        ours = {s['seed']: s for s in seeds if (s['condition'], s['method']) == (condition, 'group_spectral')}
        for method in sorted({s['method'] for s in seeds if s['condition'] == condition} - {'group_spectral'}):
            controls = {s['seed']: s for s in seeds if (s['condition'], s['method']) == (condition, method)}
            paired = [seed for seed in sorted(ours.keys() & controls.keys())
                      if ours[seed]['complete_matching_repeats'] and controls[seed]['complete_matching_repeats']]
            if not paired:
                continue
            savings = [100*(1-ours[s]['process_s']/controls[s]['process_s']) for s in paired]
            delta = [100*(ours[s]['balanced_accuracy']-controls[s]['balanced_accuracy']) for s in paired]
            descriptive_runtime_rule = (required_repeats >= 2 and len(paired) >= 5
                                        and min(savings) > 0 and st.median(savings) >= 5)
            runtime_win = accepted and descriptive_runtime_rule
            quality = min(delta) >= -1e-8
            comparisons.append(dict(condition=condition, baseline=method, n_paired_seeds=len(paired),
                median_paired_saving_percent=st.median(savings), all_seed_medians_faster=min(savings)>0,
                eligible_runtime_win=runtime_win, mean_accuracy_delta_pp=st.mean(delta),
                min_accuracy_delta_pp=min(delta), point_accuracy_at_least_each_seed=quality,
                useful_observed_win=runtime_win and quality, audit_accepted=accepted,
                audit_status=audit.get('status', 'UNKNOWN') if audit else 'MISSING',
                audit_gate_reason='; '.join(reasons)))
    all_summary = []
    for row in summary:
        ss = [s for s in seeds if (s['condition'], s['method']) == (row['condition'], row['method'])]
        all_summary.append({**row,
            'median_parent_loop_s': st.median(s['parent_loop_s'] for s in ss) if loops_available else None,
            'parent_loop_available': loops_available,
            'timing_scope': 'Parent loop includes process plus result ingestion, checkpoint/status/progress writes; sidecar writes and campaign setup/remainder are separate study costs'})
    all_comparisons = []
    for row in comparisons:
        condition, method = row['condition'], row['baseline']
        ours = {s['seed']:s for s in seeds if (s['condition'],s['method']) == (condition,'group_spectral')}
        controls = {s['seed']:s for s in seeds if (s['condition'],s['method']) == (condition,method)}
        paired = [seed for seed in sorted(ours.keys() & controls.keys())
                  if loops_available and ours[seed]['complete_matching_repeats'] and controls[seed]['complete_matching_repeats']]
        savings = [100*(1-ours[s]['parent_loop_s']/controls[s]['parent_loop_s']) for s in paired]
        delta = [100*(ours[s]['balanced_accuracy']-controls[s]['balanced_accuracy']) for s in paired]
        runtime_win = bool(accepted and required_repeats >= 2 and len(paired) >= 5
                           and min(savings) > 0 and st.median(savings) >= 5)
        quality = bool(delta and min(delta) >= -1e-8)
        all_comparisons.append(dict(condition=condition, baseline=method, n_paired_seeds=len(paired),
            median_paired_saving_percent=st.median(savings) if savings else None,
            all_seed_medians_faster=bool(savings and min(savings)>0), eligible_runtime_win=runtime_win,
            mean_accuracy_delta_pp=st.mean(delta) if delta else None,
            min_accuracy_delta_pp=min(delta) if delta else None, point_accuracy_at_least_each_seed=quality,
            useful_observed_win=runtime_win and quality, audit_accepted=accepted,
            audit_status=audit.get('status','UNKNOWN') if audit else 'MISSING',
            audit_gate_reason='; '.join(reasons), parent_loop_available=loops_available,
            unavailable_reason=loop_reason, timing_metric='parent_loop_wall_s'))
    write_csv(output, 'summary.csv', summary)
    write_csv(output, 'seed_medians.csv', seeds)
    write_csv(output, 'comparisons.csv', comparisons)
    write_csv(output, 'summary_all_overhead.csv', all_summary)
    write_csv(output, 'seed_medians_all_overhead.csv', seeds)
    write_csv(output, 'comparisons_all_overhead.csv', all_comparisons)
    study_root = campaign.parent
    phases = {path.stem[:-5]: read(path) for path in study_root.glob('*_wall.json')}
    phase_name = campaign.name.replace('campaign', 'main', 1)
    if wall_path is not None:
        external = read(wall_path).get('seconds')
        external_scope = wall_path.name
    else:
        external = phases.get(phase_name, {}).get('seconds')
        external_scope = phase_name + '_wall.json' if external is not None else 'unavailable'
    search_path = study_root/'sensor_improved_design.json'
    if not search_path.exists():
        search_path = BASE/'work/sensor_improved_design.json'
    search = read(search_path) if search_path.exists() else {}
    attempt_s = sum(r['process_wall_s'] for r in rows if isinstance(r.get('process_wall_s'), (int, float)))
    loop_s = sum(loop_values.values()) if loops_available else None
    status = read(campaign/'status.json')
    timing = dict(phases=phases, selected_campaign=campaign.name, sum_attempt_process_s=attempt_s,
        sum_attempt_parent_loop_s=loop_s,
        measured_parent_loop_overhead_s=loop_s-attempt_s if loop_s is not None else None,
        parent_loop_costs_available=loops_available, parent_loop_unavailable_reason=loop_reason,
        campaign_external_wall_s=external, campaign_external_wall_source=external_scope,
        parent_journal_overhead_s=(external-attempt_s) if external is not None else None,
        campaign_setup_gap_and_remaining_s=(external-loop_s) if external is not None and loop_s is not None else None,
        campaign_internal_timing={key:value for key,value in status.items()
                                 if key.startswith('last_invocation_') or key in ('summed_parent_loop_s','summed_parent_loop_overhead_s')},
        search_recorded_inner_s=search.get('elapsed_s'), search_import_wall_unmeasured=True,
        common_acquisition_components_s=29.555855,
        comparison_scope='Each parent-timed fresh process includes imports, dataset read/hash/split/preprocessing, construction/calibration, all training and validation selection, final test, JSON serialization and exit. Search, preflight, reporting and common initial data acquisition are separate study costs. Attempts from other campaigns are never pooled.',
        known_exclusions='Installation, unmeasured initial search imports, human/AI development time, and data-owner sensor collection/feature extraction are not measured.',
        audit_accepted=accepted, summary_generation_s=time.perf_counter()-started)
    ledger = study_cost_ledger(study_root,phases,search)
    timing.update(prior_rejected_study_phases=ledger['prior_rejected_study_phases'],
        prior_rejected_main_external_s=ledger['prior_rejected_main_external_s'],
        numerical_stability_search_external_sum_s=ledger['numerical_stability_search_external_sum_s'],
        recorded_nonoverlapping_components_sum_s=ledger['recorded_nonoverlapping_components_sum_s'],
        recorded_study_cost_status=ledger['status'],
        recorded_study_cost_scope=ledger['interpretation'],
        reporting_helper_costs_separate=ledger['reporting_helper_costs_separate'])
    (output/'study_cost_ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
    (output/'timing_accounting.json').write_text(json.dumps(timing, indent=2)+'\n')
    receipt = dict(audit_accepted=accepted, audit_status=audit.get('status', 'UNKNOWN') if audit else 'MISSING',
        audit_gate_reasons=reasons, audit_sha256=sha(audit_path) if audit_path.exists() else None,
        campaign_config_sha256=sha(campaign/'config.json'),
        attempt_file_hashes={path.name: sha(path) for path in files},
        parent_loop_sidecar_sha256=loop_hashes,
        parent_loop_costs_available=loops_available,
        primary_runtime_metric='parent_loop_wall_s when available; process_wall_s remains a separate diagnostic and excludes parent-loop work',
        rule='A qualifying win requires accepted full independent audit, at least5 complete paired seeds with at least2 matching trials, every paired seed median faster, and median paired saving>=5%. Useful observed win additionally requires no point-accuracy loss in any seed. These are descriptive, not confidence claims.',
        outputs={name:sha(output/name) for name in ('summary.csv','seed_medians.csv','comparisons.csv',
            'summary_all_overhead.csv','seed_medians_all_overhead.csv','comparisons_all_overhead.csv',
            'timing_accounting.json','study_cost_ledger.json') if (output/name).exists()})
    (output/'summary_audit_gate.json').write_text(json.dumps(receipt, indent=2)+'\n')
    return dict(summary=summary, comparisons=comparisons, summary_all_overhead=all_summary,
                comparisons_all_overhead=all_comparisons, timing=timing,
                audit_accepted=accepted, audit_gate_reasons=reasons)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', type=Path, default=DEFAULT/'campaign')
    parser.add_argument('--output', type=Path, default=DEFAULT)
    parser.add_argument('--audit', type=Path, help='Independent audit JSON; default OUTPUT/audit.json')
    parser.add_argument('--campaign-wall-file', type=Path, help='Optional external wall receipt for the selected campaign')
    args = parser.parse_args()
    print(json.dumps(summarize(args.campaign, args.output, args.audit or args.output/'audit.json',
                               args.campaign_wall_file), indent=2))


if __name__ == '__main__':
    main()
